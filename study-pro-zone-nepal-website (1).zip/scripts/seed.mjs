import "dotenv/config";
import pg from "pg";
import bcrypt from "bcryptjs";

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

const ADMIN_EMAIL = (process.env.ADMIN_EMAIL ?? "admin@studyprozone.com").toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "Admin@2026";

const img = (id) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200`;

const courses = [
  {
    slug: "see-science-full-course",
    title: "SEE Science Full Course (Class 10)",
    category: "SEE Preparation",
    level: "Beginner",
    duration: "5 months",
    price: 2500,
    summary:
      "Complete chapter-wise SEE Science preparation with experiments explained, model questions and weekly tests.",
    description:
      "This full course covers the entire SEE Science syllabus prescribed by CDC Nepal.\nEvery chapter includes a recorded video class, printable notes, numerical practice and a chapter test.\nYou also get access to five full model sets with detailed solutions and marking scheme guidance.\nOur teachers explain in easy Nepali with English scientific terms so you can answer confidently in the exam.",
    thumbnail: img(8471835),
  },
  {
    slug: "class-11-12-mathematics",
    title: "Class 11 & 12 Mathematics Masterclass",
    category: "+2 Level",
    level: "Intermediate",
    duration: "6 months",
    price: 3500,
    summary:
      "Algebra, calculus, trigonometry and statistics taught step-by-step with NEB exam-style questions.",
    description:
      "Designed for NEB students who want to score above 80 in Mathematics.\nEach topic starts from the basics and builds towards board-level problems.\nIncludes formula sheets, 300+ solved problems and monthly live doubt sessions.",
    thumbnail: img(6238297),
  },
  {
    slug: "loksewa-preparation-nasu-kharidar",
    title: "Loksewa Preparation — Nasu & Kharidar",
    category: "Loksewa",
    level: "Intermediate",
    duration: "4 months",
    price: 4500,
    summary:
      "Complete GK, Nepali, English and IQ preparation with 40+ mock tests based on the latest PSC syllabus.",
    description:
      "Structured Loksewa coaching for Kharidar and Nasu aspirants.\nCovers constitution, governance, current affairs, Nepali grammar and English usage.\nWeekly mock tests with ranking so you always know where you stand.",
    thumbnail: img(5905749),
  },
  {
    slug: "spoken-english-confidence",
    title: "Spoken English & Confidence Building",
    category: "Language",
    level: "Beginner",
    duration: "3 months",
    price: 1800,
    summary:
      "Daily speaking practice, pronunciation drills and interview preparation for students and job seekers.",
    description:
      "Learn to speak English fluently in day-to-day and professional situations.\nIncludes 60 speaking tasks, grammar refreshers and mock interview sessions on Zoom.",
    thumbnail: img(8055497),
  },
  {
    slug: "computer-basics-office-package",
    title: "Computer Basics & Office Package",
    category: "Computer",
    level: "Beginner",
    duration: "2 months",
    price: 1500,
    summary:
      "Windows, MS Word, Excel, PowerPoint, email and internet skills for school and office work.",
    description:
      "A practical computer course for students and professionals in Jhapa and beyond.\nYou will build a real CV, a marks-sheet spreadsheet and a presentation as course projects.",
    thumbnail: img(5303542),
  },
  {
    slug: "bachelor-level-account-basics",
    title: "Bachelor Level Accounting Basics",
    category: "Bachelor",
    level: "Advanced",
    duration: "4 months",
    price: 3200,
    summary:
      "Financial accounting fundamentals, journal to final accounts, with university exam question practice.",
    description:
      "Built for BBS/BBA first-year students struggling with accounting.\nWe move from double-entry basics to final accounts, cost sheets and ratio analysis.",
    thumbnail: img(5905964),
  },
];

const notes = [
  ["SEE Science — Chapter 1: Force Notes", "Science", "Class 10", "Complete notes on force, pressure and Newton's laws with solved numericals."],
  ["NEB Maths Formula Sheet (Class 11)", "Mathematics", "Class 11", "All algebra, trigonometry and calculus formulas on 6 printable pages."],
  ["Nepali Grammar for Loksewa", "Nepali", "Loksewa", "Sandhi, samas, karak and common error corrections asked in PSC exams."],
  ["English Grammar Quick Revision", "English", "All", "Tenses, voice, narration and preposition rules with 100 practice questions."],
  ["Nepal GK Current Affairs 2082", "General Knowledge", "Loksewa", "Updated facts, constitution highlights and recent national events."],
  ["Computer Fundamentals Notes", "Computer", "All", "Hardware, software, networking and MS Office shortcuts summary."],
];

const videos = [
  ["Introduction to SEE Science — Force & Motion", "Science", "https://www.youtube.com/watch?v=kKKM8Y-u7ds", "Understand force, motion and Newton's three laws with everyday Nepali examples."],
  ["Trigonometry Made Easy for Class 11", "Mathematics", "https://www.youtube.com/watch?v=PUB0TaZ7bhA", "Ratios, identities and height & distance problems solved step by step."],
  ["Spoken English: 20 Daily Sentences", "English", "https://www.youtube.com/watch?v=juKd26qkNAw", "Practice pronunciation and sentence patterns you can use from today."],
  ["Loksewa GK: Constitution of Nepal", "Loksewa", "https://www.youtube.com/watch?v=fJ9rUzIMcZQ", "Key articles, schedules and frequently asked constitution questions."],
  ["MS Excel Basics for Students", "Computer", "https://www.youtube.com/watch?v=Vl0H-qTclOg", "Create a marks sheet with formulas, charts and conditional formatting."],
  ["How to Revise Smart Before Exams", "Study Skills", "https://www.youtube.com/watch?v=IlU-zDU6aQ0", "A 7-day revision plan proven by our top scoring students."],
];

const posts = [
  [
    "see-exam-preparation-tips",
    "10 SEE Exam Preparation Tips That Actually Work",
    "Study Tips",
    "Practical, tested strategies to prepare for the SEE examination without burning out.",
    "The SEE examination decides which stream you can join, so preparation must be planned and not panicked.\nStart by making a realistic routine — two focused hours beat six distracted ones.\nSolve at least ten years of past questions; question patterns repeat more than students expect.\nWrite answers by hand within a timer so that your speed matches the real exam.\nFinally, sleep well the week before the exam. A rested brain recalls formulas faster than a tired one.",
  ],
  [
    "choose-right-stream-after-see",
    "Science, Management or Humanities? Choosing Your Stream After SEE",
    "Guidance",
    "A simple framework to pick the +2 stream that matches your strengths and career goals.",
    "Every year thousands of Nepali students choose a stream because of family pressure rather than interest.\nAsk yourself three questions: what subject do I read without being forced, what career excites me, and what are my marks realistically?\nScience opens medical and engineering paths but demands consistent lab and numerical practice.\nManagement suits students who enjoy business, accounts and communication, and it leads to BBA, BBS and CA.\nHumanities is ideal for law, social work, journalism and Loksewa aspirants.\nRemember: success depends far more on your effort than on the stream label.",
  ],
  [
    "loksewa-study-plan-90-days",
    "A 90-Day Loksewa Study Plan for Working Students",
    "Loksewa",
    "How to prepare for Kharidar and Nasu exams while managing a job or college.",
    "Ninety days is enough if every day has a defined target.\nWeeks 1-4: finish the syllabus once with short notes for every unit.\nWeeks 5-8: begin daily current affairs plus two mock tests per week.\nWeeks 9-12: revise your own notes only, and attempt one full set every alternate day.\nTrack your mock test scores in a notebook — steady improvement matters more than one high score.",
  ],
];

const pages = [
  ["about", "About Us", "Achieving excellence together", "The story, mission and people behind Study Pro Zone Nepal.", ""],
  ["courses", "Courses", "Courses built for Nepali students", "Exam preparation, language, computer and skill courses taught in simple language.", ""],
  ["notes", "Notes", "Download free study notes", "Chapter-wise notes, formula sheets and model questions prepared by our teachers.", ""],
  ["videos", "Videos", "Video classes on demand", "Stream uploaded lessons and YouTube classes from Study Pro Zone Nepal.", ""],
  ["blog", "Blog", "Study tips, notices and exam updates", "Guidance articles written by the Study Pro Zone Nepal team.", ""],
  ["contact", "Contact", "We are here to help", "Call, email or message us — we usually reply within a few hours.", ""],
];

const settings = [
  ["phone", "9806021522"],
  ["email", "Gdhakal359@gmail.com"],
  ["address", "Jhapa, Nepal"],
  ["esewaName", "Gopal Dhakal"],
  ["esewaId", "9806021522"],
  ["esewaQr", "/images/esewa-qr.png"],
];

async function main() {
  const hash = await bcrypt.hash(ADMIN_PASSWORD, 10);
  await pool.query(
    `insert into users (name, email, phone, password_hash, role)
     values ($1,$2,$3,$4,'admin')
     on conflict (email) do update set password_hash = excluded.password_hash, role = 'admin'`,
    ["Gopal Dhakal", ADMIN_EMAIL, "9806021522", hash],
  );

  const demoHash = await bcrypt.hash("student123", 10);
  await pool.query(
    `insert into users (name, email, phone, password_hash, role)
     values ($1,$2,$3,$4,'student') on conflict (email) do nothing`,
    ["Sita Sharma", "student@studyprozone.com", "9800000000", demoHash],
  );

  for (const c of courses) {
    await pool.query(
      `insert into courses (slug,title,category,level,duration,price,summary,description,thumbnail,instructor,published)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,'Gopal Dhakal',true)
       on conflict (slug) do update set title=excluded.title, summary=excluded.summary,
         description=excluded.description, thumbnail=excluded.thumbnail, price=excluded.price`,
      [c.slug, c.title, c.category, c.level, c.duration, c.price, c.summary, c.description, c.thumbnail],
    );
  }

  const { rows: noteRows } = await pool.query("select count(*)::int as n from notes");
  if (noteRows[0].n === 0) {
    for (const [title, subject, grade, description] of notes) {
      await pool.query(
        `insert into notes (title,subject,grade,description,file_url,published) values ($1,$2,$3,$4,'',true)`,
        [title, subject, grade, description],
      );
    }
  }

  const { rows: videoRows } = await pool.query("select count(*)::int as n from videos");
  if (videoRows[0].n === 0) {
    for (const [title, subject, url, description] of videos) {
      await pool.query(
        `insert into videos (title,subject,url,description,source_type,is_free,published)
         values ($1,$2,$3,$4,'youtube',true,true)`,
        [title, subject, url, description],
      );
    }
  }

  for (const [slug, title, tag, excerpt, content] of posts) {
    await pool.query(
      `insert into posts (slug,title,tag,excerpt,content,author,published)
       values ($1,$2,$3,$4,$5,'Gopal Dhakal',true)
       on conflict (slug) do update set title=excluded.title, excerpt=excluded.excerpt, content=excluded.content`,
      [slug, title, tag, excerpt, content],
    );
  }

  for (const [slug, title, heading, subheading, body] of pages) {
    await pool.query(
      `insert into pages (slug,title,heading,subheading,body) values ($1,$2,$3,$4,$5)
       on conflict (slug) do nothing`,
      [slug, title, heading, subheading, body],
    );
  }

  for (const [key, value] of settings) {
    await pool.query(
      `insert into settings (key,value) values ($1,$2) on conflict (key) do update set value = excluded.value`,
      [key, value],
    );
  }

  console.log(`Seed complete. Admin: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`);
  await pool.end();
}

main().catch(async (err) => {
  console.error(err);
  await pool.end();
  process.exit(1);
});
