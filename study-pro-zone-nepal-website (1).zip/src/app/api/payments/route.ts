import { db } from "@/db";
import { enrollments, payments } from "@/db/schema";
import { getSession } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const session = await getSession();
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;

  const fullName = String(body.fullName ?? session?.name ?? "").trim();
  const contact = String(body.contact ?? "").trim();
  const transactionId = String(body.transactionId ?? "").trim();
  const amount = Number(body.amount ?? 0);
  const courseId = body.courseId ? Number(body.courseId) : null;

  if (fullName.length < 2) return Response.json({ error: "Enter the payer name" }, { status: 400 });
  if (contact.length < 7) return Response.json({ error: "Enter a valid contact number" }, { status: 400 });
  if (transactionId.length < 4)
    return Response.json({ error: "Enter the eSewa transaction / reference code" }, { status: 400 });
  if (!Number.isFinite(amount) || amount <= 0)
    return Response.json({ error: "Enter the amount you paid" }, { status: 400 });

  const [created] = await db
    .insert(payments)
    .values({
      userId: session?.id ?? null,
      courseId,
      fullName,
      contact,
      amount: Math.trunc(amount),
      method: String(body.method ?? "eSewa"),
      transactionId,
      proofUrl: String(body.proofUrl ?? ""),
      note: String(body.note ?? ""),
      status: "pending",
    })
    .returning();

  if (session && courseId) {
    await db
      .insert(enrollments)
      .values({ userId: session.id, courseId, status: "pending" });
  }

  return Response.json({ ok: true, payment: created });
}
