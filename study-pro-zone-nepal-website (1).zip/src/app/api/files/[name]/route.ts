import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
import type { ReadableStream as WebReadableStream } from "node:stream/web";
import { Readable } from "node:stream";
import { MIME, UPLOAD_DIR } from "@/lib/uploads";

export const runtime = "nodejs";

export async function GET(request: Request, ctx: { params: Promise<{ name: string }> }) {
  const { name } = await ctx.params;
  const clean = path.basename(name);
  const filePath = path.join(UPLOAD_DIR, clean);

  let info;
  try {
    info = await stat(filePath);
  } catch {
    return new Response("Not found", { status: 404 });
  }

  const type = MIME[path.extname(clean).toLowerCase()] ?? "application/octet-stream";
  const range = request.headers.get("range");

  if (range && type.startsWith("video/")) {
    const match = /bytes=(\d*)-(\d*)/.exec(range);
    const start = match && match[1] ? Number(match[1]) : 0;
    const end = match && match[2] ? Number(match[2]) : info.size - 1;
    const stream = Readable.toWeb(
      createReadStream(filePath, { start, end }),
    ) as WebReadableStream<Uint8Array>;
    return new Response(stream as unknown as BodyInit, {
      status: 206,
      headers: {
        "Content-Type": type,
        "Content-Length": String(end - start + 1),
        "Content-Range": `bytes ${start}-${end}/${info.size}`,
        "Accept-Ranges": "bytes",
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  }

  const stream = Readable.toWeb(createReadStream(filePath)) as WebReadableStream<Uint8Array>;
  return new Response(stream as unknown as BodyInit, {
    headers: {
      "Content-Type": type,
      "Content-Length": String(info.size),
      "Accept-Ranges": "bytes",
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
