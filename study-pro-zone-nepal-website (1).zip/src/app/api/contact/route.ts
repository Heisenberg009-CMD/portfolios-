import { db } from "@/db";
import { messages } from "@/db/schema";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const name = String(body.name ?? "").trim();
  const email = String(body.email ?? "").trim();
  const message = String(body.message ?? "").trim();

  if (name.length < 2) return Response.json({ error: "Please enter your name" }, { status: 400 });
  if (!/^\S+@\S+\.\S+$/.test(email)) return Response.json({ error: "Enter a valid email" }, { status: 400 });
  if (message.length < 5) return Response.json({ error: "Please write your message" }, { status: 400 });

  await db.insert(messages).values({
    name,
    email,
    phone: String(body.phone ?? "").trim(),
    subject: String(body.subject ?? "General enquiry").trim(),
    message,
  });

  return Response.json({ ok: true });
}
