import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { getSession } from "@/lib/auth";
import { MIME, UPLOAD_DIR, safeName } from "@/lib/uploads";

export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_BYTES = 200 * 1024 * 1024; // 200 MB

export async function POST(request: Request) {
  const session = await getSession();
  if (!session) return Response.json({ error: "Sign in required" }, { status: 401 });

  const form = await request.formData().catch(() => null);
  const file = form?.get("file");
  if (!form || !(file instanceof File)) {
    return Response.json({ error: "No file received" }, { status: 400 });
  }

  const ext = path.extname(file.name).toLowerCase();
  if (!(ext in MIME)) {
    return Response.json({ error: `Unsupported file type: ${ext || "unknown"}` }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return Response.json({ error: "File is larger than 200MB" }, { status: 413 });
  }
  // Non-admins may only upload small images (payment proofs).
  if (session.role !== "admin" && !MIME[ext].startsWith("image/")) {
    return Response.json({ error: "Only image uploads are allowed" }, { status: 403 });
  }

  await mkdir(UPLOAD_DIR, { recursive: true });
  const name = safeName(file.name);
  const bytes = Buffer.from(await file.arrayBuffer());
  await writeFile(path.join(UPLOAD_DIR, name), bytes);

  return Response.json({
    ok: true,
    url: `/api/files/${name}`,
    name,
    size: file.size,
    type: MIME[ext],
  });
}
