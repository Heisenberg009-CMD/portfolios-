import { db } from "@/db";
import { settings } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export const runtime = "nodejs";

export async function GET() {
  if (!(await requireAdmin())) return Response.json({ error: "Forbidden" }, { status: 403 });
  return Response.json({ settings: await getSettings() });
}

export async function PUT(request: Request) {
  if (!(await requireAdmin())) return Response.json({ error: "Forbidden" }, { status: 403 });
  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;

  const entries = Object.entries(body).filter(([key]) => /^[a-zA-Z0-9_]{1,80}$/.test(key));
  for (const [key, value] of entries) {
    await db
      .insert(settings)
      .values({ key, value: String(value ?? "") })
      .onConflictDoUpdate({ target: settings.key, set: { value: String(value ?? "") } });
  }

  return Response.json({ ok: true, settings: await getSettings() });
}
