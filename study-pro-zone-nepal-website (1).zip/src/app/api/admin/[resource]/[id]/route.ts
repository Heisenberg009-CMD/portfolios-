/* eslint-disable @typescript-eslint/no-explicit-any */
import { db } from "@/db";
import { RESOURCES, sanitize } from "@/lib/resources";
import { requireAdmin, hashPassword } from "@/lib/auth";
import { eq } from "drizzle-orm";

export const runtime = "nodejs";

type Ctx = { params: Promise<{ resource: string; id: string }> };

export async function PATCH(request: Request, ctx: Ctx) {
  const session = await requireAdmin();
  if (!session) return Response.json({ error: "Forbidden" }, { status: 403 });
  const { resource, id } = await ctx.params;
  const def = RESOURCES[resource];
  if (!def) return Response.json({ error: "Unknown resource" }, { status: 404 });

  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const values = sanitize(def, body);

  if (resource === "users") {
    const password = String(body.password ?? "");
    if (password) {
      if (password.length < 6)
        return Response.json({ error: "Password must be at least 6 characters" }, { status: 400 });
      values.passwordHash = await hashPassword(password);
    }
    if (values.email) values.email = String(values.email).toLowerCase();
  }
  if (resource === "pages") values.updatedAt = new Date();

  try {
    const rows = (await db
      .update(def.table)
      .set(values as any)
      .where(eq((def.table as any).id, Number(id)))
      .returning()) as any[];
    const updated = rows[0];
    if (!updated) return Response.json({ error: "Not found" }, { status: 404 });
    const { passwordHash, ...rest } = updated as any;
    void passwordHash;
    return Response.json({ item: rest });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Could not update record" },
      { status: 400 },
    );
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const session = await requireAdmin();
  if (!session) return Response.json({ error: "Forbidden" }, { status: 403 });
  const { resource, id } = await ctx.params;
  const def = RESOURCES[resource];
  if (!def) return Response.json({ error: "Unknown resource" }, { status: 404 });

  if (resource === "users" && Number(id) === session.id)
    return Response.json({ error: "You cannot delete your own admin account" }, { status: 400 });

  await db.delete(def.table).where(eq((def.table as any).id, Number(id)));
  return Response.json({ ok: true });
}
