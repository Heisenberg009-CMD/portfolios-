/* eslint-disable @typescript-eslint/no-explicit-any */
import { db } from "@/db";
import { RESOURCES, sanitize } from "@/lib/resources";
import { requireAdmin, hashPassword } from "@/lib/auth";
import { desc } from "drizzle-orm";

export const runtime = "nodejs";

export async function GET(_req: Request, ctx: { params: Promise<{ resource: string }> }) {
  if (!(await requireAdmin())) return Response.json({ error: "Forbidden" }, { status: 403 });
  const { resource } = await ctx.params;
  const def = RESOURCES[resource];
  if (!def) return Response.json({ error: "Unknown resource" }, { status: 404 });

  const rows = await db.select().from(def.table).orderBy(desc((def.table as any).id)).limit(500);
  const cleaned = rows.map((row: any) => {
    const { passwordHash, ...rest } = row;
    void passwordHash;
    return rest;
  });
  return Response.json({ items: cleaned });
}

export async function POST(request: Request, ctx: { params: Promise<{ resource: string }> }) {
  if (!(await requireAdmin())) return Response.json({ error: "Forbidden" }, { status: 403 });
  const { resource } = await ctx.params;
  const def = RESOURCES[resource];
  if (!def) return Response.json({ error: "Unknown resource" }, { status: 404 });

  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const values = sanitize(def, body);

  if (resource === "users") {
    const password = String(body.password ?? "");
    if (password.length < 6)
      return Response.json({ error: "Password must be at least 6 characters" }, { status: 400 });
    values.passwordHash = await hashPassword(password);
    values.email = String(values.email ?? "").toLowerCase();
  }

  try {
    const inserted = (await db.insert(def.table).values(values as any).returning()) as any[];
    const { passwordHash, ...rest } = inserted[0] as any;
    void passwordHash;
    return Response.json({ item: rest }, { status: 201 });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Could not create record" },
      { status: 400 },
    );
  }
}
