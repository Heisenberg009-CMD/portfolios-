import { db } from "@/db";
import { courses, messages, notes, payments, posts, users, videos } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { sql, eq } from "drizzle-orm";

export const runtime = "nodejs";

export async function GET() {
  if (!(await requireAdmin())) return Response.json({ error: "Forbidden" }, { status: 403 });

  const [u] = await db.select({ n: sql<number>`count(*)::int` }).from(users);
  const [c] = await db.select({ n: sql<number>`count(*)::int` }).from(courses);
  const [v] = await db.select({ n: sql<number>`count(*)::int` }).from(videos);
  const [n] = await db.select({ n: sql<number>`count(*)::int` }).from(notes);
  const [p] = await db.select({ n: sql<number>`count(*)::int` }).from(posts);
  const [m] = await db.select({ n: sql<number>`count(*)::int` }).from(messages);
  const [pay] = await db.select({ n: sql<number>`count(*)::int` }).from(payments);
  const [pending] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(payments)
    .where(eq(payments.status, "pending"));
  const [revenue] = await db
    .select({ n: sql<number>`coalesce(sum(amount),0)::int` })
    .from(payments)
    .where(eq(payments.status, "verified"));

  return Response.json({
    users: u?.n ?? 0,
    courses: c?.n ?? 0,
    videos: v?.n ?? 0,
    notes: n?.n ?? 0,
    posts: p?.n ?? 0,
    messages: m?.n ?? 0,
    payments: pay?.n ?? 0,
    pendingPayments: pending?.n ?? 0,
    revenue: revenue?.n ?? 0,
  });
}
