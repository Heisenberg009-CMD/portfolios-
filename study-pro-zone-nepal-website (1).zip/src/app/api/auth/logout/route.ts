import { cookies } from "next/headers";
import { SESSION_COOKIE } from "@/lib/jwt";

export const runtime = "nodejs";

export async function POST() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
  return Response.json({ ok: true });
}
