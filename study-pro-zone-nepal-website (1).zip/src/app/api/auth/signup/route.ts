import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "@/lib/auth";
import { SESSION_COOKIE, signSession } from "@/lib/jwt";
import { cookies } from "next/headers";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  if (!body) return Response.json({ error: "Invalid request" }, { status: 400 });

  const name = String(body.name ?? "").trim();
  const email = String(body.email ?? "").trim().toLowerCase();
  const phone = String(body.phone ?? "").trim();
  const password = String(body.password ?? "");

  if (name.length < 2) return Response.json({ error: "Please enter your full name" }, { status: 400 });
  if (!/^\S+@\S+\.\S+$/.test(email)) return Response.json({ error: "Enter a valid email" }, { status: 400 });
  if (password.length < 6)
    return Response.json({ error: "Password must be at least 6 characters" }, { status: 400 });

  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) return Response.json({ error: "This email is already registered" }, { status: 409 });

  const passwordHash = await hashPassword(password);
  const [created] = await db
    .insert(users)
    .values({ name, email, phone, passwordHash, role: "student" })
    .returning();

  const token = await signSession({
    id: created.id,
    name: created.name,
    email: created.email,
    role: "student",
  });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
    secure: process.env.NODE_ENV === "production",
  });

  return Response.json({ ok: true, user: { id: created.id, name: created.name, role: created.role } });
}
