import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyPassword } from "@/lib/auth";
import { SESSION_COOKIE, signSession } from "@/lib/jwt";
import { cookies } from "next/headers";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  if (!body) return Response.json({ error: "Invalid request" }, { status: 400 });

  const email = String(body.email ?? "").trim().toLowerCase();
  const password = String(body.password ?? "");

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user) return Response.json({ error: "Invalid email or password" }, { status: 401 });
  if (user.status !== "active")
    return Response.json({ error: "This account has been suspended" }, { status: 403 });

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) return Response.json({ error: "Invalid email or password" }, { status: 401 });

  const role = user.role === "admin" ? "admin" : "student";
  const token = await signSession({ id: user.id, name: user.name, email: user.email, role });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
    secure: process.env.NODE_ENV === "production",
  });

  return Response.json({ ok: true, user: { id: user.id, name: user.name, role } });
}
