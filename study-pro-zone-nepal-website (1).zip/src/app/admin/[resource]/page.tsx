import { notFound } from "next/navigation";
import CrudManager from "@/components/CrudManager";
import { RESOURCES } from "@/lib/resources";

export const dynamic = "force-dynamic";

export default async function AdminResourcePage({
  params,
}: {
  params: Promise<{ resource: string }>;
}) {
  const { resource } = await params;
  const def = RESOURCES[resource];
  if (!def) notFound();

  return (
    <>
      <CrudManager resource={def.key} label={def.label} fields={def.fields} />
      {resource === "videos" && (
        <p className="mt-6 rounded-xl border border-brand-200 bg-brand-50 p-4 text-sm text-brand-800">
          <strong>Uploading videos:</strong> choose <em>Source = upload</em> and pick an MP4/WebM
          file (max 200MB) in the “Video URL / uploaded file” field — the player streams it with
          range requests. For YouTube lessons choose <em>Source = youtube</em> and paste the watch
          link.
        </p>
      )}
    </>
  );
}
