import Link from "next/link";
import { db } from "@/db";
import { messages, payments, users } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

async function counts() {
  const [u] = await db.select({ n: sql<number>`count(*)::int` }).from(users);
  const [pay] = await db.select({ n: sql<number>`count(*)::int` }).from(payments);
  const [pending] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(payments)
    .where(eq(payments.status, "pending"));
  const [revenue] = await db
    .select({ n: sql<number>`coalesce(sum(amount),0)::int` })
    .from(payments)
    .where(eq(payments.status, "verified"));
  const [msg] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(messages)
    .where(eq(messages.handled, false));
  return {
    users: u?.n ?? 0,
    payments: pay?.n ?? 0,
    pending: pending?.n ?? 0,
    revenue: revenue?.n ?? 0,
    messages: msg?.n ?? 0,
  };
}

export default async function AdminDashboard() {
  const stats = await counts();
  const [latestPayments, latestUsers, latestMessages] = await Promise.all([
    db.select().from(payments).orderBy(desc(payments.createdAt)).limit(5),
    db.select().from(users).orderBy(desc(users.createdAt)).limit(5),
    db.select().from(messages).orderBy(desc(messages.createdAt)).limit(5),
  ]);

  const cards = [
    { label: "Registered users", value: stats.users, href: "/admin/users", tone: "bg-brand-600" },
    { label: "Total payments", value: stats.payments, href: "/admin/payments", tone: "bg-emerald-600" },
    { label: "Pending verification", value: stats.pending, href: "/admin/payments", tone: "bg-amber-500" },
    { label: "Verified revenue", value: `Rs. ${stats.revenue.toLocaleString()}`, href: "/admin/payments", tone: "bg-slate-800" },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-black text-slate-900">Dashboard</h1>
        <p className="text-sm text-slate-600">
          Manage content, users and payments for Study Pro Zone Nepal.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c) => (
          <Link key={c.label} href={c.href} className={`${c.tone} rounded-2xl p-5 text-white shadow-sm`}>
            <p className="text-xs font-semibold uppercase tracking-wide opacity-80">{c.label}</p>
            <p className="mt-2 text-2xl font-black">{c.value}</p>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-extrabold text-slate-900">Recent payments</h2>
            <Link href="/admin/payments" className="text-xs font-bold text-brand-700">
              Manage →
            </Link>
          </div>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs uppercase text-slate-500">
                <tr>
                  <th className="py-2">Payer</th>
                  <th>Txn</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {latestPayments.map((p) => (
                  <tr key={p.id}>
                    <td className="py-2 font-semibold text-slate-800">{p.fullName}</td>
                    <td className="font-mono text-xs">{p.transactionId}</td>
                    <td>Rs. {p.amount}</td>
                    <td>
                      <span
                        className={`badge ${
                          p.status === "verified"
                            ? "bg-emerald-50 text-emerald-600"
                            : p.status === "rejected"
                              ? "bg-red-50 text-red-600"
                              : "bg-amber-50 text-amber-600"
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>
                  </tr>
                ))}
                {!latestPayments.length && (
                  <tr>
                    <td colSpan={4} className="py-4 text-slate-500">
                      No payments yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="text-base font-extrabold text-slate-900">New users</h2>
          <ul className="mt-4 space-y-3 text-sm">
            {latestUsers.map((u) => (
              <li key={u.id} className="flex items-center justify-between">
                <span>
                  <span className="block font-semibold text-slate-800">{u.name}</span>
                  <span className="text-xs text-slate-500">{u.email}</span>
                </span>
                <span className="badge bg-brand-50 text-brand-700">{u.role}</span>
              </li>
            ))}
            {!latestUsers.length && <li className="text-slate-500">No users yet.</li>}
          </ul>
        </div>
      </div>

      <div className="card p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-extrabold text-slate-900">
            Latest messages{" "}
            {stats.messages > 0 && (
              <span className="badge ml-2 bg-amber-50 text-amber-600">{stats.messages} new</span>
            )}
          </h2>
          <Link href="/admin/messages" className="text-xs font-bold text-brand-700">
            Inbox →
          </Link>
        </div>
        <ul className="mt-4 space-y-3 text-sm">
          {latestMessages.map((m) => (
            <li key={m.id} className="rounded-lg border border-slate-100 p-3">
              <p className="font-semibold text-slate-800">
                {m.name} · <span className="text-xs font-normal text-slate-500">{m.email}</span>
              </p>
              <p className="mt-1 line-clamp-2 text-slate-600">{m.message}</p>
            </li>
          ))}
          {!latestMessages.length && <li className="text-slate-500">Inbox is empty.</li>}
        </ul>
      </div>
    </div>
  );
}
