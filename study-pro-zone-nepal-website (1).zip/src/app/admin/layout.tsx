import type { ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { SITE } from "@/lib/site";
import AdminNav from "@/components/AdminNav";
import LogoutButton from "@/components/LogoutButton";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin Panel" };

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const admin = await requireAdmin();
  if (!admin) redirect("/login?next=/admin&admin=1");

  return (
    <div className="min-h-screen bg-slate-50 lg:flex">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-brand-900 p-5 text-brand-100 lg:flex">
        <Link href="/admin" className="flex items-center gap-3">
          <Image
            src={SITE.logo}
            alt={SITE.name}
            width={44}
            height={44}
            className="h-11 w-11 rounded-full bg-white object-cover"
          />
          <span>
            <span className="block text-sm font-extrabold text-white">Admin Panel</span>
            <span className="block text-[11px] text-brand-300">Study Pro Zone Nepal</span>
          </span>
        </Link>
        <AdminNav />
        <div className="mt-auto rounded-xl bg-white/10 p-3 text-xs">
          <p className="font-bold text-white">{admin.name}</p>
          <p className="truncate text-brand-200">{admin.email}</p>
          <Link href="/" className="mt-2 inline-block font-semibold text-white hover:underline">
            ← View website
          </Link>
        </div>
      </aside>

      <div className="flex-1">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 lg:px-8">
          <div className="flex items-center gap-3 lg:hidden">
            <Image
              src={SITE.logo}
              alt={SITE.name}
              width={36}
              height={36}
              className="h-9 w-9 rounded-full object-cover"
            />
            <span className="text-sm font-extrabold text-brand-800">Admin</span>
          </div>
          <p className="hidden text-sm font-semibold text-slate-500 lg:block">
            Secure admin area — restricted to administrators
          </p>
          <div className="flex items-center gap-2">
            <Link href="/" className="btn btn-ghost px-3 py-1.5 text-xs">
              Website
            </Link>
            <LogoutButton />
          </div>
        </header>
        <div className="p-4 lg:p-8">
          <div className="lg:hidden">
            <AdminNav mobile />
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}
