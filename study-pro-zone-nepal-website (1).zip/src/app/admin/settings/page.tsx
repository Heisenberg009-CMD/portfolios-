import SettingsManager from "@/components/SettingsManager";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function AdminSettingsPage() {
  const settings = await getSettings();
  return <SettingsManager initial={settings} />;
}
