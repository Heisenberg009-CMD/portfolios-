import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { payments, enrollments, courses } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { getCourses, getVideos } from "@/lib/queries";
import { VideoCard } from "@/components/Cards";

export const dynamic = "force-dynamic";
export const metadata = { title: "My Dashboard" };

export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login?next=/dashboard");

  const [myPayments, myEnrollments, allCourses, videos] = await Promise.all([
    db.select().from(payments).where(eq(payments.userId, session.id)).orderBy(desc(payments.createdAt)),
    db
      .select({ id: enrollments.id, status: enrollments.status, title: courses.title, slug: courses.slug })
      .from(enrollments)
      .leftJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.userId, session.id)),
    getCourses(3),
    getVideos(4),
  ]);

  return (
    <section className="container-x py-12">
      <div className="rounded-2xl bg-gradient-to-r from-brand-700 to-brand-500 p-8 text-white">
        <h1 className="text-2xl font-black sm:text-3xl">Namaste, {session.name} 👋</h1>
        <p className="mt-2 text-brand-100">
          Track your enrolments, payments and continue learning where you left off.
        </p>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <div className="card p-6">
            <h2 className="text-lg font-extrabold text-slate-900">My enrolments</h2>
            {myEnrollments.length ? (
              <ul className="mt-4 divide-y divide-slate-100">
                {myEnrollments.map((e) => (
                  <li key={e.id} className="flex items-center justify-between py-3">
                    <span className="text-sm font-semibold text-slate-800">{e.title}</span>
                    <span
                      className={`badge ${
                        e.status === "active"
                          ? "bg-emerald-50 text-emerald-600"
                          : "bg-amber-50 text-amber-600"
                      }`}
                    >
                      {e.status}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-3 text-sm text-slate-600">
                You have not enrolled yet.{" "}
                <Link href="/courses" className="font-bold text-brand-700">
                  Browse courses →
                </Link>
              </p>
            )}
          </div>

          <div className="card p-6">
            <h2 className="text-lg font-extrabold text-slate-900">My payments</h2>
            {myPayments.length ? (
              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="text-xs uppercase text-slate-500">
                    <tr>
                      <th className="py-2">Date</th>
                      <th>Method</th>
                      <th>Txn ID</th>
                      <th>Amount</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {myPayments.map((p) => (
                      <tr key={p.id}>
                        <td className="py-2">{new Date(p.createdAt).toLocaleDateString("en-GB")}</td>
                        <td>{p.method}</td>
                        <td className="font-mono text-xs">{p.transactionId}</td>
                        <td>Rs. {p.amount}</td>
                        <td>
                          <span
                            className={`badge ${
                              p.status === "verified"
                                ? "bg-emerald-50 text-emerald-600"
                                : p.status === "rejected"
                                  ? "bg-red-50 text-red-600"
                                  : "bg-amber-50 text-amber-600"
                            }`}
                          >
                            {p.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="mt-3 text-sm text-slate-600">
                No payments submitted.{" "}
                <Link href="/payment" className="font-bold text-brand-700">
                  Pay with eSewa →
                </Link>
              </p>
            )}
          </div>

          <div>
            <h2 className="mb-4 text-lg font-extrabold text-slate-900">Continue watching</h2>
            <div className="grid gap-5 sm:grid-cols-2">
              {videos.slice(0, 2).map((v) => (
                <VideoCard key={v.id} video={v} />
              ))}
            </div>
          </div>
        </div>

        <aside className="card h-fit p-6">
          <h2 className="text-base font-extrabold text-slate-900">Recommended courses</h2>
          <ul className="mt-4 space-y-4">
            {allCourses.map((c) => (
              <li key={c.id}>
                <Link href={`/courses/${c.slug}`} className="text-sm font-bold text-brand-700 hover:underline">
                  {c.title}
                </Link>
                <p className="text-xs text-slate-500">
                  {c.level} · {c.price > 0 ? `Rs. ${c.price}` : "Free"}
                </p>
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </section>
  );
}
