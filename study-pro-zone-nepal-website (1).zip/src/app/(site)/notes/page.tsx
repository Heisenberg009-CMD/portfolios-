import PageHero from "@/components/PageHero";
import { getNotes, getPage } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata = { title: "Notes" };

export default async function NotesPage() {
  const [notes, page] = await Promise.all([getNotes(), getPage("notes")]);

  return (
    <>
      <PageHero
        eyebrow="Study notes"
        title={page?.heading || "Download free study notes"}
        subtitle={
          page?.subheading ||
          "Chapter-wise notes, formula sheets, model questions and past paper solutions prepared by our teachers."
        }
      />
      <section className="container-x py-12">
        {notes.length ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {notes.map((n) => (
              <article key={n.id} className="card flex flex-col p-6">
                <div className="flex items-center gap-2">
                  <span className="badge bg-brand-50 text-brand-700">{n.subject}</span>
                  <span className="badge bg-slate-100 text-slate-600">{n.grade}</span>
                </div>
                <h3 className="mt-3 text-lg font-bold text-slate-900">{n.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-600">{n.description}</p>
                {n.fileUrl ? (
                  <a
                    href={n.fileUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-primary mt-4"
                  >
                    ⬇ Download
                  </a>
                ) : (
                  <span className="mt-4 text-xs font-semibold text-slate-400">
                    File uploading soon
                  </span>
                )}
              </article>
            ))}
          </div>
        ) : (
          <p className="text-slate-500">Notes will be published shortly.</p>
        )}
      </section>
    </>
  );
}
