/* eslint-disable @next/next/no-img-element */
import Image from "next/image";
import Link from "next/link";
import { CourseCard, PostCard, SectionTitle, VideoCard } from "@/components/Cards";
import { getCourses, getNotes, getPosts, getVideos } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

const FEATURES = [
  {
    icon: "🎯",
    title: "Exam-focused courses",
    text: "SEE, +2, Bachelor and Loksewa preparation built around the real syllabus and past papers.",
  },
  {
    icon: "📝",
    title: "Ready-made notes",
    text: "Chapter-wise notes, formula sheets and model questions you can download and revise offline.",
  },
  {
    icon: "🎬",
    title: "Video classes",
    text: "Recorded lessons in simple Nepali + English that you can replay any time, on any device.",
  },
  {
    icon: "🤝",
    title: "Mentor support",
    text: "Direct guidance from Gopal Dhakal and the Study Pro Zone team over phone and messenger.",
  },
];

export default async function HomePage() {
  const [courses, videos, posts, notes, settings] = await Promise.all([
    getCourses(6),
    getVideos(4),
    getPosts(3),
    getNotes(4),
    getSettings(),
  ]);

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-brand-900 via-brand-700 to-brand-500 text-white">
        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-2xl" />
        <div className="pointer-events-none absolute -bottom-32 left-1/3 h-80 w-80 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="container-x relative grid items-center gap-10 py-16 md:py-24 lg:grid-cols-2">
          <div>
            <span className="badge bg-white/15 text-white">{SITE.tagline}</span>
            <h1 className="mt-4 text-3xl font-black leading-tight tracking-tight sm:text-4xl lg:text-5xl">
              {settings.heroTitle}
            </h1>
            <p className="mt-4 max-w-xl text-base text-brand-100 sm:text-lg">
              {settings.heroSubtitle}
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/courses" className="btn bg-white text-brand-700 hover:bg-brand-50">
                Browse Courses
              </Link>
              <Link href="/signup" className="btn border border-white/40 bg-white/10 text-white hover:bg-white/20">
                Create Free Account
              </Link>
              <Link href="/videos" className="btn border border-white/40 bg-transparent text-white hover:bg-white/10">
                ▶ Watch Free Classes
              </Link>
            </div>
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4 text-center">
              {[
                { k: "2,500+", v: "Students" },
                { k: `${courses.length || 6}+`, v: "Courses" },
                { k: "24/7", v: "Access" },
              ].map((s) => (
                <div key={s.v} className="rounded-xl bg-white/10 px-3 py-3 backdrop-blur">
                  <dt className="text-xl font-extrabold">{s.k}</dt>
                  <dd className="text-xs font-medium text-brand-100">{s.v}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="relative mx-auto w-full max-w-md">
            <div className="rounded-3xl bg-white/10 p-5 backdrop-blur ring-1 ring-white/25">
              <Image
                src={SITE.logo}
                alt={SITE.name}
                width={420}
                height={420}
                className="mx-auto h-64 w-64 rounded-full bg-white object-cover shadow-2xl sm:h-80 sm:w-80"
                priority
              />
              <p className="mt-4 text-center text-sm font-semibold uppercase tracking-wide text-brand-100">
                {SITE.motto}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container-x py-14">
        <SectionTitle
          eyebrow="Why students choose us"
          title="Everything you need to score higher"
          subtitle="One platform for classes, notes, videos and mentorship — designed for Nepali students."
        />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <div key={f.title} className="card p-6">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-50 text-xl">
                {f.icon}
              </div>
              <h3 className="mt-4 text-base font-bold text-slate-900">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Courses */}
      <section className="bg-slate-50 py-14">
        <div className="container-x">
          <SectionTitle
            eyebrow="Courses"
            title="Popular courses running now"
            subtitle="Structured classes with live doubt-solving, assignments and certificates."
            action={{ href: "/courses", label: "All courses" }}
          />
          {courses.length ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {courses.map((c) => (
                <CourseCard key={c.id} course={c} />
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-500">Courses will appear here soon.</p>
          )}
        </div>
      </section>

      {/* Videos */}
      <section className="container-x py-14">
        <SectionTitle
          eyebrow="Video classes"
          title="Watch free video lessons"
          subtitle="Recorded and uploaded by our teachers — stream on mobile data without buffering."
          action={{ href: "/videos", label: "Video library" }}
        />
        {videos.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {videos.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-500">Videos will be published soon.</p>
        )}
      </section>

      {/* Notes + Payment */}
      <section className="bg-slate-50 py-14">
        <div className="container-x grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <SectionTitle
              eyebrow="Notes"
              title="Fresh study notes"
              action={{ href: "/notes", label: "All notes" }}
            />
            <div className="grid gap-4 sm:grid-cols-2">
              {notes.length ? (
                notes.map((n) => (
                  <div key={n.id} className="card p-5">
                    <span className="badge bg-brand-50 text-brand-700">{n.subject}</span>
                    <h3 className="mt-2 text-base font-bold text-slate-900">{n.title}</h3>
                    <p className="mt-1 line-clamp-2 text-sm text-slate-600">{n.description}</p>
                    <Link href="/notes" className="mt-3 inline-block text-sm font-bold text-brand-700">
                      Open notes →
                    </Link>
                  </div>
                ))
              ) : (
                <p className="text-sm text-slate-500">Notes will be uploaded soon.</p>
              )}
            </div>
          </div>

          <div className="card p-6 text-center">
            <span className="badge bg-emerald-50 text-emerald-600">eSewa Payment</span>
            <h3 className="mt-3 text-lg font-extrabold text-slate-900">Pay fees in seconds</h3>
            <p className="mt-1 text-sm text-slate-600">
              Scan with your eSewa app — {settings.esewaName} ({settings.esewaId})
            </p>
            <img
              src={settings.esewaQr || SITE.qr}
              alt="eSewa QR code"
              className="mx-auto mt-4 h-48 w-48 rounded-xl border border-slate-200 bg-white p-2"
              loading="lazy"
            />
            <Link href="/payment" className="btn btn-primary mt-5 w-full">
              Submit payment details
            </Link>
          </div>
        </div>
      </section>

      {/* Blog */}
      <section className="container-x py-14">
        <SectionTitle
          eyebrow="Blog"
          title="Study tips & exam updates"
          action={{ href: "/blog", label: "All articles" }}
        />
        {posts.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {posts.map((p) => (
              <PostCard key={p.slug} post={p} />
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-500">Articles coming soon.</p>
        )}
      </section>

      {/* CTA */}
      <section className="container-x pb-4">
        <div className="rounded-3xl bg-gradient-to-r from-brand-700 to-brand-500 px-6 py-12 text-center text-white sm:px-12">
          <h2 className="text-2xl font-extrabold sm:text-3xl">Ready to start your journey?</h2>
          <p className="mx-auto mt-3 max-w-2xl text-brand-100">
            Join Study Pro Zone Nepal today and get instant access to free lessons, notes and a
            supportive learning community from Jhapa to the whole of Nepal.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link href="/signup" className="btn bg-white text-brand-700 hover:bg-brand-50">
              Sign Up Free
            </Link>
            <a href={`tel:${settings.phone}`} className="btn border border-white/50 bg-white/10 text-white">
              📞 {settings.phone}
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
