import { Suspense } from "react";
import Image from "next/image";
import AuthForm from "@/components/AuthForm";
import { SITE } from "@/lib/site";

export const metadata = { title: "Sign Up" };

export default function SignupPage() {
  return (
    <section className="container-x grid items-center gap-10 py-14 lg:grid-cols-2">
      <div className="hidden lg:block">
        <Image
          src={SITE.logo}
          alt={SITE.name}
          width={320}
          height={320}
          className="mx-auto h-72 w-72 rounded-full object-cover"
        />
        <ul className="mx-auto mt-6 max-w-sm space-y-2 text-sm text-slate-700">
          <li>✅ Free access to sample video classes</li>
          <li>✅ Download notes and model questions</li>
          <li>✅ Track your enrolments and payments</li>
          <li>✅ Get exam notices before anyone else</li>
        </ul>
      </div>
      <div className="mx-auto w-full max-w-md">
        <Suspense fallback={<div className="card p-7 text-sm text-slate-500">Loading…</div>}>
          <AuthForm mode="signup" />
        </Suspense>
      </div>
    </section>
  );
}
