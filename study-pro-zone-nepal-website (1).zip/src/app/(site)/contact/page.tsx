/* eslint-disable @next/next/no-img-element */
import PageHero from "@/components/PageHero";
import ContactForm from "@/components/ContactForm";
import { getPage } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";
export const metadata = { title: "Contact" };

export default async function ContactPage() {
  const [page, settings] = await Promise.all([getPage("contact"), getSettings()]);

  return (
    <>
      <PageHero
        eyebrow="Contact"
        title={page?.heading || "We are here to help"}
        subtitle={page?.subheading || "Call, email or message us — we usually reply within a few hours."}
      />
      <section className="container-x grid gap-8 py-12 lg:grid-cols-3">
        <div className="space-y-5">
          <div className="card p-6">
            <h2 className="text-lg font-extrabold text-slate-900">Contact details</h2>
            <ul className="mt-4 space-y-3 text-sm text-slate-700">
              <li>
                📞{" "}
                <a className="font-semibold text-brand-700" href={`tel:${settings.phone}`}>
                  {settings.phone}
                </a>
              </li>
              <li>
                ✉️{" "}
                <a className="font-semibold text-brand-700" href={`mailto:${settings.email}`}>
                  {settings.email}
                </a>
              </li>
              <li>📍 {settings.address}</li>
              <li>🕘 Sunday – Friday, 7:00 AM – 7:00 PM</li>
            </ul>
          </div>
          <div className="card p-6 text-center">
            <h2 className="text-base font-extrabold text-slate-900">Pay with eSewa</h2>
            <img
              src={settings.esewaQr || SITE.qr}
              alt="eSewa QR"
              className="mx-auto mt-3 h-44 w-44 rounded-xl border border-slate-200 p-2"
              loading="lazy"
            />
            <p className="mt-2 text-sm font-semibold text-slate-700">
              {settings.esewaName} · {settings.esewaId}
            </p>
          </div>
        </div>
        <div className="lg:col-span-2">
          <ContactForm />
          <div className="card mt-6 overflow-hidden">
            <iframe
              title="Study Pro Zone Nepal location"
              className="h-72 w-full"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              src="https://www.google.com/maps?q=Jhapa,Nepal&output=embed"
            />
          </div>
        </div>
      </section>
    </>
  );
}
