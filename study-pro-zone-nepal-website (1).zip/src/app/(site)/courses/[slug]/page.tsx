/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCourse, getVideos } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { VideoCard } from "@/components/Cards";

export const dynamic = "force-dynamic";

export default async function CourseDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const course = await getCourse(slug);
  if (!course) notFound();
  const [videos, settings] = await Promise.all([getVideos(4), getSettings()]);

  return (
    <>
      <section className="bg-gradient-to-r from-brand-900 to-brand-600 py-12 text-white">
        <div className="container-x grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <span className="badge bg-white/15 text-white">{course.category}</span>
            <h1 className="mt-3 text-3xl font-black sm:text-4xl">{course.title}</h1>
            <p className="mt-3 max-w-2xl text-brand-100">{course.summary}</p>
            <div className="mt-5 flex flex-wrap gap-4 text-sm text-brand-100">
              <span>👤 {course.instructor}</span>
              <span>📶 {course.level}</span>
              <span>⏱ {course.duration}</span>
            </div>
          </div>
          <div className="card bg-white p-6 text-slate-900">
            {course.thumbnail && (
              <img
                src={course.thumbnail}
                alt={course.title}
                className="mb-4 h-40 w-full rounded-xl object-cover"
              />
            )}
            <p className="text-3xl font-black text-brand-700">
              {course.price > 0 ? `Rs. ${course.price.toLocaleString()}` : "Free"}
            </p>
            <p className="mt-1 text-sm text-slate-600">Lifetime access · Certificate included</p>
            <Link
              href={`/payment?course=${course.id}&amount=${course.price}`}
              className="btn btn-primary mt-4 w-full"
            >
              Enroll via eSewa
            </Link>
            <a href={`tel:${settings.phone}`} className="btn btn-ghost mt-2 w-full">
              📞 Talk to a counsellor
            </a>
          </div>
        </div>
      </section>

      <section className="container-x grid gap-10 py-12 lg:grid-cols-3">
        <article className="prose-body lg:col-span-2">
          <h2 className="text-2xl font-extrabold text-slate-900">About this course</h2>
          <div className="mt-4 space-y-4 text-slate-700">
            {(course.description || course.summary)
              .split("\n")
              .filter(Boolean)
              .map((para, i) => (
                <p key={i} className="leading-relaxed">
                  {para}
                </p>
              ))}
          </div>
        </article>
        <aside className="card h-fit p-6">
          <h3 className="text-base font-bold text-slate-900">What you get</h3>
          <ul className="mt-3 space-y-2 text-sm text-slate-700">
            <li>✅ Recorded video classes</li>
            <li>✅ Downloadable chapter notes</li>
            <li>✅ Model questions and mock tests</li>
            <li>✅ Doubt solving on messenger</li>
            <li>✅ Completion certificate</li>
          </ul>
        </aside>
      </section>

      {videos.length > 0 && (
        <section className="container-x pb-14">
          <h2 className="mb-6 text-xl font-extrabold text-slate-900">Sample video lessons</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {videos.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        </section>
      )}
    </>
  );
}
