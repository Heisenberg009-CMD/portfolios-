import { CourseCard } from "@/components/Cards";
import PageHero from "@/components/PageHero";
import { getCourses } from "@/lib/queries";
import { getPage } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata = { title: "Courses" };

export default async function CoursesPage() {
  const [courses, page] = await Promise.all([getCourses(), getPage("courses")]);
  const categories = Array.from(new Set(courses.map((c) => c.category)));

  return (
    <>
      <PageHero
        eyebrow="Courses"
        title={page?.heading || "Courses built for Nepali students"}
        subtitle={
          page?.subheading ||
          "Choose from exam preparation, language, computer and skill courses — all taught in simple language with practical examples."
        }
      />
      <section className="container-x py-12">
        {categories.length > 0 && (
          <div className="mb-8 flex flex-wrap gap-2">
            {categories.map((cat) => (
              <span key={cat} className="badge bg-brand-50 text-brand-700">
                {cat}
              </span>
            ))}
          </div>
        )}
        {courses.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {courses.map((c) => (
              <CourseCard key={c.id} course={c} />
            ))}
          </div>
        ) : (
          <p className="text-slate-500">No published courses yet. Please check back soon.</p>
        )}
      </section>
    </>
  );
}
