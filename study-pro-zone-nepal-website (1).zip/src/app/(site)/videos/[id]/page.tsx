import { notFound } from "next/navigation";
import VideoPlayer from "@/components/VideoPlayer";
import { VideoCard } from "@/components/Cards";
import { getVideo, getVideos } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function VideoDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const video = await getVideo(Number(id));
  if (!video) notFound();
  const others = (await getVideos(8)).filter((v) => v.id !== video.id).slice(0, 4);

  return (
    <section className="container-x grid gap-10 py-10 lg:grid-cols-3">
      <div className="lg:col-span-2">
        <VideoPlayer
          url={video.url}
          sourceType={video.sourceType}
          title={video.title}
          poster={video.thumbnail}
        />
        <div className="mt-5 flex flex-wrap items-center gap-2">
          <span className="badge bg-brand-50 text-brand-700">{video.subject}</span>
          {video.isFree && <span className="badge bg-emerald-50 text-emerald-600">Free lesson</span>}
          <span className="text-xs text-slate-500">
            Published {new Date(video.createdAt).toLocaleDateString("en-GB")}
          </span>
        </div>
        <h1 className="mt-3 text-2xl font-extrabold text-slate-900 sm:text-3xl">{video.title}</h1>
        <p className="mt-3 whitespace-pre-line leading-relaxed text-slate-700">{video.description}</p>
      </div>
      <aside>
        <h2 className="mb-4 text-lg font-extrabold text-slate-900">More lessons</h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-1">
          {others.map((v) => (
            <VideoCard key={v.id} video={v} />
          ))}
        </div>
      </aside>
    </section>
  );
}
