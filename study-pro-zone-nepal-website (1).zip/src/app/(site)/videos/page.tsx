import Link from "next/link";
import PageHero from "@/components/PageHero";
import { VideoCard } from "@/components/Cards";
import { getPage, getVideos } from "@/lib/queries";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const metadata = { title: "Videos" };

export default async function VideosPage() {
  const [videos, page, session] = await Promise.all([getVideos(), getPage("videos"), getSession()]);

  return (
    <>
      <PageHero
        eyebrow="Video library"
        title={page?.heading || "Video classes on demand"}
        subtitle={
          page?.subheading ||
          "Stream uploaded lessons and YouTube classes from Study Pro Zone Nepal — replay as many times as you need."
        }
      />
      <section className="container-x py-12">
        {session?.role === "admin" && (
          <div className="mb-8 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-brand-200 bg-brand-50 p-4">
            <p className="text-sm font-semibold text-brand-800">
              You are signed in as admin — upload new video lessons from the admin panel.
            </p>
            <Link href="/admin/videos" className="btn btn-primary">
              Upload video
            </Link>
          </div>
        )}
        {videos.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {videos.map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        ) : (
          <p className="text-slate-500">No videos published yet.</p>
        )}
      </section>
    </>
  );
}
