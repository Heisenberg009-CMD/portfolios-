/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { notFound } from "next/navigation";
import { getPost } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function BlogDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) notFound();

  return (
    <article className="container-x max-w-3xl py-12">
      <Link href="/blog" className="text-sm font-bold text-brand-700 hover:underline">
        ← Back to blog
      </Link>
      <div className="mt-4 flex items-center gap-2 text-xs text-slate-500">
        <span className="badge bg-brand-50 text-brand-700">{post.tag}</span>
        <span>{new Date(post.createdAt).toLocaleDateString("en-GB")}</span>
        <span>· {post.author}</span>
      </div>
      <h1 className="mt-3 text-3xl font-black leading-tight text-slate-900">{post.title}</h1>
      {post.cover && (
        <img src={post.cover} alt={post.title} className="mt-6 w-full rounded-2xl object-cover" />
      )}
      <div className="prose-body mt-6 space-y-4 text-slate-700">
        {post.content
          .split("\n")
          .filter(Boolean)
          .map((para, i) => (
            <p key={i} className="leading-relaxed">
              {para}
            </p>
          ))}
      </div>
    </article>
  );
}
