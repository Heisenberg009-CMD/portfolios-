import PageHero from "@/components/PageHero";
import { PostCard } from "@/components/Cards";
import { getPage, getPosts } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata = { title: "Blog" };

export default async function BlogPage() {
  const [posts, page] = await Promise.all([getPosts(), getPage("blog")]);
  return (
    <>
      <PageHero
        eyebrow="Blog"
        title={page?.heading || "Study tips, notices and exam updates"}
        subtitle={page?.subheading || "Guidance articles written by the Study Pro Zone Nepal team."}
      />
      <section className="container-x py-12">
        {posts.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {posts.map((p) => (
              <PostCard key={p.slug} post={p} />
            ))}
          </div>
        ) : (
          <p className="text-slate-500">No articles published yet.</p>
        )}
      </section>
    </>
  );
}
