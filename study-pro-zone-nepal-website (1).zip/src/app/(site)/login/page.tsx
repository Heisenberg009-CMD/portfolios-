import { Suspense } from "react";
import Image from "next/image";
import AuthForm from "@/components/AuthForm";
import { SITE } from "@/lib/site";

export const metadata = { title: "Login" };

export default function LoginPage() {
  return (
    <section className="container-x grid items-center gap-10 py-14 lg:grid-cols-2">
      <div className="hidden lg:block">
        <Image
          src={SITE.logo}
          alt={SITE.name}
          width={320}
          height={320}
          className="mx-auto h-72 w-72 rounded-full object-cover"
        />
        <h2 className="mt-6 text-center text-2xl font-black text-brand-800">{SITE.name}</h2>
        <p className="mt-2 text-center text-slate-600">{SITE.motto}</p>
      </div>
      <div className="mx-auto w-full max-w-md">
        <Suspense fallback={<div className="card p-7 text-sm text-slate-500">Loading…</div>}>
          <AuthForm mode="login" />
        </Suspense>
      </div>
    </section>
  );
}
