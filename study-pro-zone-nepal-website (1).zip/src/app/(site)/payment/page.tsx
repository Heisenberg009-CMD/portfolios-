/* eslint-disable @next/next/no-img-element */
import PageHero from "@/components/PageHero";
import PaymentForm from "@/components/PaymentForm";
import { getCourses } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { getSession } from "@/lib/auth";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";
export const metadata = { title: "Payment" };

export default async function PaymentPage({
  searchParams,
}: {
  searchParams: Promise<{ course?: string; amount?: string }>;
}) {
  const [params, courses, settings, session] = await Promise.all([
    searchParams,
    getCourses(),
    getSettings(),
    getSession(),
  ]);

  return (
    <>
      <PageHero
        eyebrow="Payment"
        title="Pay securely with eSewa"
        subtitle={settings.paymentNote}
      />
      <section className="container-x grid gap-8 py-12 lg:grid-cols-3">
        <div className="space-y-5">
          <div className="card p-6 text-center">
            <span className="badge bg-emerald-50 text-emerald-600">eSewa QR</span>
            <img
              src={settings.esewaQr || SITE.qr}
              alt="eSewa QR code"
              className="mx-auto mt-4 w-full max-w-[260px] rounded-xl border border-slate-200 bg-white p-3"
            />
            <p className="mt-3 text-base font-extrabold text-slate-900">{settings.esewaName}</p>
            <p className="text-sm text-slate-600">{settings.esewaId}</p>
          </div>
          <div className="card p-6 text-sm text-slate-700">
            <h3 className="text-base font-bold text-slate-900">Other payment options</h3>
            <p className="mt-3">🏦 {settings.bankDetails}</p>
            <p className="mt-2">📱 Khalti: {settings.khaltiId}</p>
            <p className="mt-2">📞 Support: {settings.phone}</p>
          </div>
        </div>
        <div className="lg:col-span-2">
          <PaymentForm
            courses={courses.map((c) => ({ id: c.id, title: c.title, price: c.price }))}
            defaultCourseId={params.course}
            defaultAmount={params.amount}
            canUpload={Boolean(session)}
          />
          <ol className="card mt-6 space-y-3 p-6 text-sm text-slate-700">
            <li>
              <strong className="text-brand-700">1.</strong> Open the eSewa app and scan the QR
              above.
            </li>
            <li>
              <strong className="text-brand-700">2.</strong> Enter the course fee and complete the
              payment.
            </li>
            <li>
              <strong className="text-brand-700">3.</strong> Submit the transaction ID using this
              form.
            </li>
            <li>
              <strong className="text-brand-700">4.</strong> We verify and unlock your course
              access — you will get a confirmation call.
            </li>
          </ol>
        </div>
      </section>
    </>
  );
}
