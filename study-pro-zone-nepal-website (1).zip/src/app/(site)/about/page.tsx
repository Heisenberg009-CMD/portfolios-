import Image from "next/image";
import Link from "next/link";
import PageHero from "@/components/PageHero";
import { getPage } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";
export const metadata = { title: "About" };

export default async function AboutPage() {
  const [page, settings] = await Promise.all([getPage("about"), getSettings()]);
  const body =
    page?.body ||
    `Study Pro Zone Nepal is an education initiative based in Jhapa, Nepal, founded to make quality learning affordable and reachable for every student.
We started with small tuition batches and grew into a digital learning platform offering recorded video classes, downloadable notes, exam-focused courses and one-to-one mentoring.
Our teaching philosophy is simple: explain concepts in the language students actually speak, practice with real exam questions, and never let a doubt go unanswered.
Today students from Jhapa, Morang, Sunsari, Kathmandu and beyond study with us — preparing for SEE, +2, Bachelor level and Loksewa examinations.`;

  return (
    <>
      <PageHero
        eyebrow="About us"
        title={page?.heading || "Achieving excellence together"}
        subtitle={page?.subheading || "The story, mission and people behind Study Pro Zone Nepal."}
      />

      <section className="container-x grid items-start gap-10 py-12 lg:grid-cols-3">
        <div className="prose-body lg:col-span-2">
          {body
            .split("\n")
            .filter(Boolean)
            .map((p, i) => (
              <p key={i} className="mb-4 leading-relaxed text-slate-700">
                {p}
              </p>
            ))}

          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            <div className="card p-6">
              <h3 className="text-base font-bold text-brand-700">🎯 Our mission</h3>
              <p className="mt-2 text-sm text-slate-600">
                Deliver affordable, high-quality education to every Nepali student regardless of
                where they live or what they can pay.
              </p>
            </div>
            <div className="card p-6">
              <h3 className="text-base font-bold text-brand-700">🌄 Our vision</h3>
              <p className="mt-2 text-sm text-slate-600">
                Become Nepal&apos;s most trusted digital study zone where hard work today turns into
                a relaxed, successful tomorrow.
              </p>
            </div>
          </div>
        </div>

        <aside className="card p-6 text-center">
          <Image
            src={SITE.logo}
            alt={SITE.name}
            width={200}
            height={200}
            className="mx-auto h-40 w-40 rounded-full object-cover"
          />
          <h3 className="mt-4 text-lg font-extrabold text-slate-900">{SITE.name}</h3>
          <p className="text-sm text-slate-600">{SITE.tagline}</p>
          <div className="mt-4 space-y-2 text-left text-sm text-slate-700">
            <p>📞 {settings.phone}</p>
            <p>✉️ {settings.email}</p>
            <p>📍 {settings.address}</p>
          </div>
          <Link href="/contact" className="btn btn-primary mt-5 w-full">
            Contact us
          </Link>
        </aside>
      </section>
    </>
  );
}
