import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  integer,
  boolean,
  jsonb,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull().unique(),
  phone: varchar("phone", { length: 40 }),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 20 }).notNull().default("student"),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  title: varchar("title", { length: 240 }).notNull(),
  category: varchar("category", { length: 120 }).notNull().default("General"),
  level: varchar("level", { length: 60 }).notNull().default("Beginner"),
  duration: varchar("duration", { length: 80 }).notNull().default("4 weeks"),
  price: integer("price").notNull().default(0),
  instructor: varchar("instructor", { length: 160 }).notNull().default("Gopal Dhakal"),
  summary: text("summary").notNull().default(""),
  description: text("description").notNull().default(""),
  thumbnail: text("thumbnail").notNull().default(""),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 240 }).notNull(),
  subject: varchar("subject", { length: 120 }).notNull().default("General"),
  grade: varchar("grade", { length: 80 }).notNull().default("All"),
  description: text("description").notNull().default(""),
  fileUrl: text("file_url").notNull().default(""),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 240 }).notNull(),
  subject: varchar("subject", { length: 120 }).notNull().default("General"),
  description: text("description").notNull().default(""),
  sourceType: varchar("source_type", { length: 20 }).notNull().default("youtube"),
  url: text("url").notNull().default(""),
  thumbnail: text("thumbnail").notNull().default(""),
  isFree: boolean("is_free").notNull().default(true),
  published: boolean("published").notNull().default(true),
  views: integer("views").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  title: varchar("title", { length: 240 }).notNull(),
  author: varchar("author", { length: 160 }).notNull().default("Study Pro Zone Nepal"),
  tag: varchar("tag", { length: 80 }).notNull().default("Study Tips"),
  excerpt: text("excerpt").notNull().default(""),
  content: text("content").notNull().default(""),
  cover: text("cover").notNull().default(""),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const pages = pgTable("pages", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  title: varchar("title", { length: 240 }).notNull(),
  heading: varchar("heading", { length: 240 }).notNull().default(""),
  subheading: text("subheading").notNull().default(""),
  body: text("body").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  key: varchar("key", { length: 120 }).primaryKey(),
  value: text("value").notNull().default(""),
});

export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  courseId: integer("course_id").notNull(),
  status: varchar("status", { length: 24 }).notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  courseId: integer("course_id"),
  fullName: varchar("full_name", { length: 160 }).notNull().default(""),
  contact: varchar("contact", { length: 60 }).notNull().default(""),
  amount: integer("amount").notNull().default(0),
  method: varchar("method", { length: 40 }).notNull().default("eSewa"),
  transactionId: varchar("transaction_id", { length: 120 }).notNull().default(""),
  proofUrl: text("proof_url").notNull().default(""),
  status: varchar("status", { length: 24 }).notNull().default("pending"),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull().default(""),
  subject: varchar("subject", { length: 200 }).notNull().default(""),
  message: text("message").notNull(),
  handled: boolean("handled").notNull().default(false),
  meta: jsonb("meta"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
