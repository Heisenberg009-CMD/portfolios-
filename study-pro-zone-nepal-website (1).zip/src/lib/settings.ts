import { db } from "@/db";
import { settings } from "@/db/schema";
import { SITE } from "@/lib/site";

export type SiteSettings = Record<string, string>;

export const DEFAULT_SETTINGS: SiteSettings = {
  phone: SITE.phone,
  email: SITE.email,
  address: SITE.address,
  esewaName: SITE.esewaName,
  esewaId: SITE.esewaId,
  esewaQr: SITE.qr,
  bankDetails: "Nabil Bank · A/C 0123456789012 · Gopal Dhakal · Birtamode Branch",
  khaltiId: SITE.phone,
  paymentNote:
    "Scan the eSewa QR, pay the course fee, then submit your transaction ID below. Access is unlocked after verification (usually within a few hours).",
  facebook: "https://facebook.com/studyprozonenepal",
  youtube: "https://youtube.com/@studyprozonenepal",
  tiktok: "https://tiktok.com/@studyprozonenepal",
  heroTitle: "Learn smarter with Study Pro Zone Nepal",
  heroSubtitle:
    "Live classes, exam-ready notes, recorded video lessons and mentorship for students across Nepal.",
};

export async function getSettings(): Promise<SiteSettings> {
  try {
    const rows = await db.select().from(settings);
    const map: SiteSettings = { ...DEFAULT_SETTINGS };
    for (const row of rows) map[row.key] = row.value;
    return map;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}
