import { SignJWT, jwtVerify } from "jose";

export const SESSION_COOKIE = "spz_session";

export type SessionUser = {
  id: number;
  name: string;
  email: string;
  role: "admin" | "student";
};

function secret() {
  const value =
    process.env.AUTH_SECRET ?? "study-pro-zone-nepal-dev-secret-key-change-me-2026";
  return new TextEncoder().encode(value);
}

export async function signSession(user: SessionUser) {
  return await new SignJWT({ ...user })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret());
}

export async function verifySession(token: string | undefined): Promise<SessionUser | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    if (typeof payload.id !== "number" || typeof payload.email !== "string") return null;
    return {
      id: payload.id,
      name: String(payload.name ?? ""),
      email: payload.email,
      role: payload.role === "admin" ? "admin" : "student",
    };
  } catch {
    return null;
  }
}
