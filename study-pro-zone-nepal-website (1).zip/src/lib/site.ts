export const SITE = {
  name: "Study Pro Zone Nepal",
  tagline: "Achieving Excellence Together",
  motto: "Work Harder Today · Relax and Enjoy Tomorrow",
  phone: "9806021522",
  email: "Gdhakal359@gmail.com",
  address: "Jhapa, Nepal",
  esewaName: "Gopal Dhakal",
  esewaId: "9806021522",
  logo: "/images/logo.png",
  qr: "/images/esewa-qr.png",
};

export const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/courses", label: "Courses" },
  { href: "/notes", label: "Notes" },
  { href: "/videos", label: "Videos" },
  { href: "/blog", label: "Blog" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 90);
}

export function youtubeId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=)([\w-]{6,})/,
    /(?:youtu\.be\/)([\w-]{6,})/,
    /(?:youtube\.com\/embed\/)([\w-]{6,})/,
    /(?:youtube\.com\/shorts\/)([\w-]{6,})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}
