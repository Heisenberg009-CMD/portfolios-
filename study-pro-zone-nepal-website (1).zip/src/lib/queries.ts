import { db } from "@/db";
import { courses, notes, posts, videos, pages } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";

export async function getCourses(limit = 100) {
  try {
    return await db
      .select()
      .from(courses)
      .where(eq(courses.published, true))
      .orderBy(desc(courses.createdAt))
      .limit(limit);
  } catch {
    return [];
  }
}

export async function getCourse(slug: string) {
  try {
    const rows = await db.select().from(courses).where(eq(courses.slug, slug)).limit(1);
    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export async function getNotes(limit = 100) {
  try {
    return await db
      .select()
      .from(notes)
      .where(eq(notes.published, true))
      .orderBy(desc(notes.createdAt))
      .limit(limit);
  } catch {
    return [];
  }
}

export async function getVideos(limit = 100) {
  try {
    return await db
      .select()
      .from(videos)
      .where(eq(videos.published, true))
      .orderBy(desc(videos.createdAt))
      .limit(limit);
  } catch {
    return [];
  }
}

export async function getVideo(id: number) {
  try {
    const rows = await db
      .select()
      .from(videos)
      .where(and(eq(videos.id, id), eq(videos.published, true)))
      .limit(1);
    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export async function getPosts(limit = 100) {
  try {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.published, true))
      .orderBy(desc(posts.createdAt))
      .limit(limit);
  } catch {
    return [];
  }
}

export async function getPost(slug: string) {
  try {
    const rows = await db.select().from(posts).where(eq(posts.slug, slug)).limit(1);
    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export async function getPage(slug: string) {
  try {
    const rows = await db.select().from(pages).where(eq(pages.slug, slug)).limit(1);
    return rows[0] ?? null;
  } catch {
    return null;
  }
}
