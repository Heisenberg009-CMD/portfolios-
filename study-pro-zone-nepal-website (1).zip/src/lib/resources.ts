/* eslint-disable @typescript-eslint/no-explicit-any */
import { courses, notes, videos, posts, pages, payments, messages, users } from "@/db/schema";
import { slugify } from "@/lib/site";

export type FieldType = "string" | "text" | "number" | "boolean";

export type FieldDef = {
  name: string;
  label: string;
  type: FieldType;
  options?: string[];
  required?: boolean;
  hideInTable?: boolean;
};

export type ResourceDef = {
  key: string;
  label: string;
  table: any;
  fields: FieldDef[];
  slugFrom?: string;
  orderBy?: string;
};

export const RESOURCES: Record<string, ResourceDef> = {
  courses: {
    key: "courses",
    label: "Courses",
    table: courses,
    slugFrom: "title",
    fields: [
      { name: "title", label: "Title", type: "string", required: true },
      { name: "category", label: "Category", type: "string" },
      {
        name: "level",
        label: "Level",
        type: "string",
        options: ["Beginner", "Intermediate", "Advanced"],
      },
      { name: "duration", label: "Duration", type: "string" },
      { name: "price", label: "Price (NPR)", type: "number" },
      { name: "instructor", label: "Instructor", type: "string" },
      { name: "summary", label: "Short summary", type: "text", hideInTable: true },
      { name: "description", label: "Full description", type: "text", hideInTable: true },
      { name: "thumbnail", label: "Thumbnail URL", type: "string", hideInTable: true },
      { name: "published", label: "Published", type: "boolean" },
    ],
  },
  notes: {
    key: "notes",
    label: "Notes",
    table: notes,
    fields: [
      { name: "title", label: "Title", type: "string", required: true },
      { name: "subject", label: "Subject", type: "string" },
      { name: "grade", label: "Grade / Level", type: "string" },
      { name: "description", label: "Description", type: "text", hideInTable: true },
      { name: "fileUrl", label: "File URL (upload or link)", type: "string", hideInTable: true },
      { name: "published", label: "Published", type: "boolean" },
    ],
  },
  videos: {
    key: "videos",
    label: "Videos",
    table: videos,
    fields: [
      { name: "title", label: "Title", type: "string", required: true },
      { name: "subject", label: "Subject", type: "string" },
      {
        name: "sourceType",
        label: "Source",
        type: "string",
        options: ["youtube", "upload", "external"],
      },
      { name: "url", label: "Video URL / uploaded file", type: "string" },
      { name: "thumbnail", label: "Thumbnail URL", type: "string", hideInTable: true },
      { name: "description", label: "Description", type: "text", hideInTable: true },
      { name: "isFree", label: "Free preview", type: "boolean" },
      { name: "published", label: "Published", type: "boolean" },
    ],
  },
  posts: {
    key: "posts",
    label: "Blog posts",
    table: posts,
    slugFrom: "title",
    fields: [
      { name: "title", label: "Title", type: "string", required: true },
      { name: "tag", label: "Tag", type: "string" },
      { name: "author", label: "Author", type: "string" },
      { name: "excerpt", label: "Excerpt", type: "text", hideInTable: true },
      { name: "content", label: "Content", type: "text", hideInTable: true },
      { name: "cover", label: "Cover image URL", type: "string", hideInTable: true },
      { name: "published", label: "Published", type: "boolean" },
    ],
  },
  pages: {
    key: "pages",
    label: "Pages",
    table: pages,
    fields: [
      { name: "slug", label: "Slug", type: "string", required: true },
      { name: "title", label: "Page title", type: "string", required: true },
      { name: "heading", label: "Heading", type: "string" },
      { name: "subheading", label: "Sub heading", type: "text", hideInTable: true },
      { name: "body", label: "Body content", type: "text", hideInTable: true },
    ],
  },
  payments: {
    key: "payments",
    label: "Payments",
    table: payments,
    fields: [
      { name: "fullName", label: "Payer name", type: "string", required: true },
      { name: "contact", label: "Contact", type: "string" },
      { name: "amount", label: "Amount (NPR)", type: "number" },
      { name: "method", label: "Method", type: "string", options: ["eSewa", "Khalti", "Bank", "Cash"] },
      { name: "transactionId", label: "Transaction ID", type: "string" },
      { name: "courseId", label: "Course ID", type: "number" },
      { name: "proofUrl", label: "Payment proof URL", type: "string", hideInTable: true },
      {
        name: "status",
        label: "Status",
        type: "string",
        options: ["pending", "verified", "rejected"],
      },
      { name: "note", label: "Note", type: "text", hideInTable: true },
    ],
  },
  messages: {
    key: "messages",
    label: "Messages",
    table: messages,
    fields: [
      { name: "name", label: "Name", type: "string", required: true },
      { name: "email", label: "Email", type: "string" },
      { name: "phone", label: "Phone", type: "string" },
      { name: "subject", label: "Subject", type: "string" },
      { name: "message", label: "Message", type: "text", hideInTable: true },
      { name: "handled", label: "Handled", type: "boolean" },
    ],
  },
  users: {
    key: "users",
    label: "Users",
    table: users,
    fields: [
      { name: "name", label: "Name", type: "string", required: true },
      { name: "email", label: "Email", type: "string", required: true },
      { name: "phone", label: "Phone", type: "string" },
      { name: "role", label: "Role", type: "string", options: ["student", "admin"] },
      { name: "status", label: "Status", type: "string", options: ["active", "suspended"] },
    ],
  },
};

export function sanitize(def: ResourceDef, body: Record<string, unknown>) {
  const values: Record<string, unknown> = {};
  for (const field of def.fields) {
    if (!(field.name in body)) continue;
    const raw = body[field.name];
    if (field.type === "number") {
      const n = Number(raw);
      values[field.name] = Number.isFinite(n) ? Math.trunc(n) : 0;
    } else if (field.type === "boolean") {
      values[field.name] = raw === true || raw === "true" || raw === "on";
    } else {
      values[field.name] = raw === null || raw === undefined ? "" : String(raw);
    }
  }
  if (def.slugFrom) {
    const source = body.slug ? String(body.slug) : String(body[def.slugFrom] ?? "");
    if (source) values.slug = slugify(source) || `item-${Date.now()}`;
  }
  return values;
}
