/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { youtubeId } from "@/lib/site";

export function SectionTitle({
  eyebrow,
  title,
  subtitle,
  action,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  action?: { href: string; label: string };
}) {
  return (
    <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow && (
          <span className="badge bg-brand-50 text-brand-700">{eyebrow}</span>
        )}
        <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-slate-900 sm:text-3xl">
          {title}
        </h2>
        {subtitle && <p className="mt-2 max-w-2xl text-sm text-slate-600">{subtitle}</p>}
      </div>
      {action && (
        <Link href={action.href} className="btn btn-ghost self-start sm:self-auto">
          {action.label} →
        </Link>
      )}
    </div>
  );
}

export type CourseCardData = {
  id: number;
  slug: string;
  title: string;
  category: string;
  level: string;
  duration: string;
  price: number;
  summary: string;
  thumbnail: string;
};

export function CourseCard({ course }: { course: CourseCardData }) {
  return (
    <article className="card flex flex-col overflow-hidden">
      <div className="relative h-40 w-full overflow-hidden bg-brand-50">
        {course.thumbnail ? (
          <img
            src={course.thumbnail}
            alt={course.title}
            className="h-full w-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-brand-600 to-brand-400 text-3xl font-black text-white/90">
            {course.title.slice(0, 2).toUpperCase()}
          </div>
        )}
        <span className="absolute left-3 top-3 badge bg-white/95 text-brand-700">
          {course.category}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
          <span>{course.level}</span>
          <span>•</span>
          <span>{course.duration}</span>
        </div>
        <h3 className="mt-2 text-lg font-bold leading-snug text-slate-900">{course.title}</h3>
        <p className="mt-2 line-clamp-3 flex-1 text-sm text-slate-600">{course.summary}</p>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-lg font-extrabold text-brand-700">
            {course.price > 0 ? `Rs. ${course.price.toLocaleString()}` : "Free"}
          </span>
          <Link href={`/courses/${course.slug}`} className="btn btn-primary">
            View course
          </Link>
        </div>
      </div>
    </article>
  );
}

export type VideoCardData = {
  id: number;
  title: string;
  subject: string;
  thumbnail: string;
  url: string;
  sourceType: string;
  isFree: boolean;
};

export function VideoCard({ video }: { video: VideoCardData }) {
  const yt = youtubeId(video.url);
  const thumb = video.thumbnail || (yt ? `https://img.youtube.com/vi/${yt}/hqdefault.jpg` : "");
  return (
    <Link href={`/videos/${video.id}`} className="card group flex flex-col overflow-hidden">
      <div className="relative aspect-video w-full bg-slate-900">
        {thumb ? (
          <img src={thumb} alt={video.title} className="h-full w-full object-cover opacity-90" loading="lazy" />
        ) : (
          <div className="h-full w-full bg-gradient-to-br from-slate-800 to-brand-700" />
        )}
        <span className="absolute inset-0 flex items-center justify-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white/90 text-brand-700 shadow-lg transition group-hover:scale-110">
            ▶
          </span>
        </span>
        <span className="absolute left-3 top-3 badge bg-white/90 text-brand-700">{video.subject}</span>
        {video.isFree && (
          <span className="absolute right-3 top-3 badge bg-emerald-500 text-white">Free</span>
        )}
      </div>
      <div className="p-4">
        <h3 className="line-clamp-2 text-sm font-bold text-slate-900 group-hover:text-brand-700">
          {video.title}
        </h3>
      </div>
    </Link>
  );
}

export type PostCardData = {
  slug: string;
  title: string;
  tag: string;
  excerpt: string;
  cover: string;
  createdAt: Date | string;
};

export function PostCard({ post }: { post: PostCardData }) {
  const date = new Date(post.createdAt).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
  return (
    <article className="card flex flex-col overflow-hidden">
      {post.cover ? (
        <img src={post.cover} alt={post.title} className="h-40 w-full object-cover" loading="lazy" />
      ) : (
        <div className="h-40 w-full bg-gradient-to-br from-brand-100 to-brand-50" />
      )}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
          <span className="badge bg-brand-50 text-brand-700">{post.tag}</span>
          <span>{date}</span>
        </div>
        <h3 className="mt-2 text-lg font-bold leading-snug text-slate-900">{post.title}</h3>
        <p className="mt-2 line-clamp-3 flex-1 text-sm text-slate-600">{post.excerpt}</p>
        <Link href={`/blog/${post.slug}`} className="mt-4 text-sm font-bold text-brand-700 hover:underline">
          Read article →
        </Link>
      </div>
    </article>
  );
}
