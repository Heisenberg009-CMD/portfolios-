/* eslint-disable @next/next/no-img-element */
"use client";

import { useState } from "react";

const GROUPS: { title: string; fields: { key: string; label: string; textarea?: boolean }[] }[] = [
  {
    title: "Contact information",
    fields: [
      { key: "phone", label: "Phone" },
      { key: "email", label: "Email" },
      { key: "address", label: "Address" },
    ],
  },
  {
    title: "Homepage hero",
    fields: [
      { key: "heroTitle", label: "Hero title" },
      { key: "heroSubtitle", label: "Hero subtitle", textarea: true },
    ],
  },
  {
    title: "Payment details",
    fields: [
      { key: "esewaName", label: "eSewa account name" },
      { key: "esewaId", label: "eSewa ID / mobile" },
      { key: "esewaQr", label: "eSewa QR image URL" },
      { key: "khaltiId", label: "Khalti ID" },
      { key: "bankDetails", label: "Bank details", textarea: true },
      { key: "paymentNote", label: "Payment instructions", textarea: true },
    ],
  },
  {
    title: "Social links",
    fields: [
      { key: "facebook", label: "Facebook URL" },
      { key: "youtube", label: "YouTube URL" },
      { key: "tiktok", label: "TikTok URL" },
    ],
  },
];

export default function SettingsManager({ initial }: { initial: Record<string, string> }) {
  const [values, setValues] = useState<Record<string, string>>(initial);
  const [status, setStatus] = useState<"idle" | "saving" | "saved">("idle");
  const [error, setError] = useState("");

  async function uploadQr(file: File) {
    const body = new FormData();
    body.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(data.error ?? "Upload failed");
      return;
    }
    setValues((v) => ({ ...v, esewaQr: data.url }));
  }

  async function save() {
    setStatus("saving");
    setError("");
    const res = await fetch("/api/admin/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(data.error ?? "Could not save settings");
      setStatus("idle");
      return;
    }
    setValues(data.settings ?? values);
    setStatus("saved");
    setTimeout(() => setStatus("idle"), 2500);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-slate-900">Site settings</h1>
          <p className="text-sm text-slate-600">
            Contact details, payment gateway and homepage content used across the website.
          </p>
        </div>
        <button className="btn btn-primary" onClick={save} disabled={status === "saving"}>
          {status === "saving" ? "Saving…" : "Save changes"}
        </button>
      </div>

      {status === "saved" && (
        <p className="rounded-lg bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
          ✅ Settings saved and live on the website.
        </p>
      )}
      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">{error}</p>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        {GROUPS.map((group) => (
          <section key={group.title} className="card p-6">
            <h2 className="text-base font-extrabold text-slate-900">{group.title}</h2>
            <div className="mt-4 space-y-4">
              {group.fields.map((f) => (
                <div key={f.key}>
                  <label className="label" htmlFor={f.key}>
                    {f.label}
                  </label>
                  {f.textarea ? (
                    <textarea
                      id={f.key}
                      rows={3}
                      className="textarea"
                      value={values[f.key] ?? ""}
                      onChange={(e) => setValues({ ...values, [f.key]: e.target.value })}
                    />
                  ) : (
                    <input
                      id={f.key}
                      className="input"
                      value={values[f.key] ?? ""}
                      onChange={(e) => setValues({ ...values, [f.key]: e.target.value })}
                    />
                  )}
                  {f.key === "esewaQr" && (
                    <div className="mt-3 flex items-center gap-4">
                      {values.esewaQr && (
                        <img
                          src={values.esewaQr}
                          alt="eSewa QR"
                          className="h-24 w-24 rounded-lg border border-slate-200 p-1"
                        />
                      )}
                      <input
                        type="file"
                        accept="image/*"
                        className="block w-full text-xs text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-50 file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-brand-700"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) void uploadQr(file);
                        }}
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
