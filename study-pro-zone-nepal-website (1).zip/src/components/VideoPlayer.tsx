"use client";

import { youtubeId } from "@/lib/site";

export default function VideoPlayer({
  url,
  sourceType,
  title,
  poster,
}: {
  url: string;
  sourceType: string;
  title: string;
  poster?: string;
}) {
  const yt = youtubeId(url);

  if (!url) {
    return (
      <div className="flex aspect-video w-full items-center justify-center rounded-xl bg-slate-100 text-sm text-slate-500">
        Video source not available yet.
      </div>
    );
  }

  if (sourceType === "youtube" || yt) {
    return (
      <div className="aspect-video w-full overflow-hidden rounded-xl bg-black">
        <iframe
          className="h-full w-full"
          src={`https://www.youtube.com/embed/${yt ?? ""}`}
          title={title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          loading="lazy"
        />
      </div>
    );
  }

  return (
    <video
      className="aspect-video w-full rounded-xl bg-black"
      controls
      preload="metadata"
      poster={poster || undefined}
    >
      <source src={url} />
      Your browser does not support the video tag.
    </video>
  );
}
