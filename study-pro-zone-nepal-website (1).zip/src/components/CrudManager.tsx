"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { FieldDef } from "@/lib/resources";

type Row = Record<string, unknown>;

const FILE_FIELDS = new Set(["url", "fileUrl", "thumbnail", "cover", "proofUrl", "esewaQr"]);

export default function CrudManager({
  resource,
  label,
  fields,
}: {
  resource: string;
  label: string;
  fields: FieldDef[];
}) {
  const [items, setItems] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<Row | null>(null);
  const [creating, setCreating] = useState(false);
  const [query, setQuery] = useState("");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<string | null>(null);
  const [form, setForm] = useState<Row>({});

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch(`/api/admin/${resource}`);
    const data = await res.json().catch(() => ({}));
    setLoading(false);
    if (!res.ok) {
      setError(data.error ?? "Could not load data");
      return;
    }
    setItems(data.items ?? []);
  }, [resource]);

  useEffect(() => {
    void load();
  }, [load]);

  const tableFields = useMemo(() => fields.filter((f) => !f.hideInTable).slice(0, 5), [fields]);

  const filtered = useMemo(() => {
    if (!query.trim()) return items;
    const q = query.toLowerCase();
    return items.filter((row) =>
      Object.values(row).some((v) => String(v ?? "").toLowerCase().includes(q)),
    );
  }, [items, query]);

  function openCreate() {
    const initial: Row = {};
    for (const f of fields) {
      initial[f.name] = f.type === "boolean" ? true : f.type === "number" ? 0 : "";
    }
    setForm(initial);
    setEditing(null);
    setCreating(true);
  }

  function openEdit(row: Row) {
    setForm({ ...row });
    setEditing(row);
    setCreating(true);
  }

  async function upload(fieldName: string, file: File) {
    setUploading(fieldName);
    setError("");
    const body = new FormData();
    body.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body });
    const data = await res.json().catch(() => ({}));
    setUploading(null);
    if (!res.ok) {
      setError(data.error ?? "Upload failed");
      return;
    }
    setForm((f) => ({
      ...f,
      [fieldName]: data.url,
      ...(fieldName === "url" && resource === "videos" ? { sourceType: "upload" } : {}),
    }));
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setError("");
    const id = editing?.id;
    const res = await fetch(id ? `/api/admin/${resource}/${id}` : `/api/admin/${resource}`, {
      method: id ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json().catch(() => ({}));
    setSaving(false);
    if (!res.ok) {
      setError(data.error ?? "Could not save");
      return;
    }
    setCreating(false);
    setEditing(null);
    void load();
  }

  async function remove(row: Row) {
    if (!confirm("Delete this record permanently?")) return;
    const res = await fetch(`/api/admin/${resource}/${row.id}`, { method: "DELETE" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(data.error ?? "Could not delete");
      return;
    }
    void load();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-slate-900">{label}</h1>
          <p className="text-sm text-slate-600">{filtered.length} record(s)</p>
        </div>
        <div className="flex gap-2">
          <input
            className="input w-48"
            placeholder="Search…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <button className="btn btn-primary" onClick={openCreate}>
            + New
          </button>
        </div>
      </div>

      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">{error}</p>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3">ID</th>
              {tableFields.map((f) => (
                <th key={f.name} className="px-4 py-3">
                  {f.label}
                </th>
              ))}
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading && (
              <tr>
                <td className="px-4 py-6 text-slate-500" colSpan={tableFields.length + 2}>
                  Loading…
                </td>
              </tr>
            )}
            {!loading &&
              filtered.map((row) => (
                <tr key={String(row.id)} className="hover:bg-slate-50">
                  <td className="px-4 py-3 text-xs text-slate-400">{String(row.id)}</td>
                  {tableFields.map((f) => {
                    const value = row[f.name];
                    return (
                      <td key={f.name} className="max-w-[240px] truncate px-4 py-3 text-slate-700">
                        {typeof value === "boolean" ? (
                          <span
                            className={`badge ${value ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-500"}`}
                          >
                            {value ? "yes" : "no"}
                          </span>
                        ) : (
                          String(value ?? "")
                        )}
                      </td>
                    );
                  })}
                  <td className="whitespace-nowrap px-4 py-3 text-right">
                    <button
                      className="text-xs font-bold text-brand-700 hover:underline"
                      onClick={() => openEdit(row)}
                    >
                      Edit
                    </button>
                    <button
                      className="ml-3 text-xs font-bold text-red-600 hover:underline"
                      onClick={() => remove(row)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            {!loading && !filtered.length && (
              <tr>
                <td className="px-4 py-6 text-slate-500" colSpan={tableFields.length + 2}>
                  No records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {creating && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-900/50 p-4">
          <form
            onSubmit={save}
            className="my-8 w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl"
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-extrabold text-slate-900">
                {editing ? "Edit" : "Create"} {label.replace(/s$/, "")}
              </h2>
              <button
                type="button"
                className="text-slate-400 hover:text-slate-700"
                onClick={() => setCreating(false)}
              >
                ✕
              </button>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {fields.map((f) => (
                <div key={f.name} className={f.type === "text" ? "sm:col-span-2" : ""}>
                  <label className="label" htmlFor={f.name}>
                    {f.label}
                  </label>
                  {f.type === "boolean" ? (
                    <select
                      id={f.name}
                      className="select"
                      value={form[f.name] ? "true" : "false"}
                      onChange={(e) => setForm({ ...form, [f.name]: e.target.value === "true" })}
                    >
                      <option value="true">Yes</option>
                      <option value="false">No</option>
                    </select>
                  ) : f.options ? (
                    <select
                      id={f.name}
                      className="select"
                      value={String(form[f.name] ?? "")}
                      onChange={(e) => setForm({ ...form, [f.name]: e.target.value })}
                    >
                      {f.options.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  ) : f.type === "text" ? (
                    <textarea
                      id={f.name}
                      rows={4}
                      className="textarea"
                      value={String(form[f.name] ?? "")}
                      onChange={(e) => setForm({ ...form, [f.name]: e.target.value })}
                    />
                  ) : (
                    <input
                      id={f.name}
                      type={f.type === "number" ? "number" : "text"}
                      className="input"
                      required={f.required}
                      value={String(form[f.name] ?? "")}
                      onChange={(e) => setForm({ ...form, [f.name]: e.target.value })}
                    />
                  )}
                  {FILE_FIELDS.has(f.name) && (
                    <div className="mt-2">
                      <input
                        type="file"
                        className="block w-full text-xs text-slate-500 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-50 file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-brand-700"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) void upload(f.name, file);
                        }}
                      />
                      {uploading === f.name && (
                        <p className="mt-1 text-xs text-brand-700">Uploading… please wait</p>
                      )}
                    </div>
                  )}
                </div>
              ))}

              {resource === "users" && (
                <div className="sm:col-span-2">
                  <label className="label" htmlFor="password">
                    Password {editing ? "(leave blank to keep current)" : ""}
                  </label>
                  <input
                    id="password"
                    type="text"
                    className="input"
                    value={String(form.password ?? "")}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                  />
                </div>
              )}
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button type="button" className="btn btn-ghost" onClick={() => setCreating(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" disabled={saving}>
                {saving ? "Saving…" : "Save"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
