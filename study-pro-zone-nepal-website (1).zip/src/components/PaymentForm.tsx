"use client";

import { useState } from "react";

type CourseOption = { id: number; title: string; price: number };

export default function PaymentForm({
  courses,
  defaultCourseId,
  defaultAmount,
  canUpload,
}: {
  courses: CourseOption[];
  defaultCourseId?: string;
  defaultAmount?: string;
  canUpload: boolean;
}) {
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");
  const [error, setError] = useState("");
  const [proofUrl, setProofUrl] = useState("");
  const [uploading, setUploading] = useState(false);

  async function uploadProof(file: File) {
    setUploading(true);
    setError("");
    const body = new FormData();
    body.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body });
    const data = await res.json().catch(() => ({}));
    setUploading(false);
    if (!res.ok) {
      setError(data.error ?? "Upload failed");
      return;
    }
    setProofUrl(data.url);
  }

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("loading");
    setError("");
    const form = new FormData(event.currentTarget);
    const payload = { ...Object.fromEntries(form.entries()), proofUrl };
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(data.error ?? "Could not submit payment");
      setStatus("idle");
      return;
    }
    event.currentTarget.reset();
    setProofUrl("");
    setStatus("done");
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-4 p-6">
      <h2 className="text-lg font-extrabold text-slate-900">Submit your payment details</h2>
      {status === "done" && (
        <p className="rounded-lg bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700">
          ✅ Payment submitted! Our team will verify it and unlock your access shortly.
        </p>
      )}
      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">{error}</p>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="fullName">
            Payer full name
          </label>
          <input id="fullName" name="fullName" className="input" required />
        </div>
        <div>
          <label className="label" htmlFor="contact">
            Contact number
          </label>
          <input id="contact" name="contact" className="input" required placeholder="98XXXXXXXX" />
        </div>
        <div>
          <label className="label" htmlFor="courseId">
            Course
          </label>
          <select id="courseId" name="courseId" className="select" defaultValue={defaultCourseId ?? ""}>
            <option value="">General / other payment</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.title} — Rs. {c.price}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="amount">
            Amount paid (NPR)
          </label>
          <input
            id="amount"
            name="amount"
            type="number"
            min={1}
            className="input"
            required
            defaultValue={defaultAmount ?? ""}
          />
        </div>
        <div>
          <label className="label" htmlFor="method">
            Payment method
          </label>
          <select id="method" name="method" className="select" defaultValue="eSewa">
            <option>eSewa</option>
            <option>Khalti</option>
            <option>Bank</option>
            <option>Cash</option>
          </select>
        </div>
        <div>
          <label className="label" htmlFor="transactionId">
            Transaction / reference ID
          </label>
          <input id="transactionId" name="transactionId" className="input" required />
        </div>
      </div>

      {canUpload && (
        <div>
          <label className="label" htmlFor="proof">
            Payment screenshot (optional)
          </label>
          <input
            id="proof"
            type="file"
            accept="image/*"
            className="input"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void uploadProof(file);
            }}
          />
          {uploading && <p className="mt-1 text-xs text-slate-500">Uploading…</p>}
          {proofUrl && <p className="mt-1 text-xs font-semibold text-emerald-600">Screenshot attached ✓</p>}
        </div>
      )}

      <div>
        <label className="label" htmlFor="note">
          Note (optional)
        </label>
        <textarea id="note" name="note" rows={3} className="textarea" />
      </div>

      <button className="btn btn-primary w-full" disabled={status === "loading"}>
        {status === "loading" ? "Submitting…" : "Submit payment"}
      </button>
      {!canUpload && (
        <p className="text-xs text-slate-500">
          Tip: sign in to attach a payment screenshot and track verification from your dashboard.
        </p>
      )}
    </form>
  );
}
