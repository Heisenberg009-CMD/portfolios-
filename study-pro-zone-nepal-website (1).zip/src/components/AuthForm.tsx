"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

export default function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const search = useSearchParams();
  const next = search.get("next");
  const adminHint = search.get("admin") === "1";
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    const payload = Object.fromEntries(new FormData(event.currentTarget).entries());
    const res = await fetch(`/api/auth/${mode}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    setLoading(false);
    if (!res.ok) {
      setError(data.error ?? "Something went wrong");
      return;
    }
    const destination = next || (data.user?.role === "admin" ? "/admin" : "/dashboard");
    router.push(destination);
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-4 p-7">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">
          {mode === "login" ? "Welcome back" : "Create your free account"}
        </h1>
        <p className="mt-1 text-sm text-slate-600">
          {mode === "login"
            ? "Log in to access your courses, notes and videos."
            : "Join Study Pro Zone Nepal and start learning today."}
        </p>
      </div>

      {adminHint && (
        <p className="rounded-lg bg-brand-50 px-4 py-3 text-sm font-semibold text-brand-700">
          🔒 Admin area — please sign in with an administrator account.
        </p>
      )}
      {error && (
        <p className="rounded-lg bg-red-50 px-4 py-3 text-sm font-semibold text-red-600">{error}</p>
      )}

      {mode === "signup" && (
        <>
          <div>
            <label className="label" htmlFor="name">
              Full name
            </label>
            <input id="name" name="name" className="input" required placeholder="Ram Bahadur" />
          </div>
          <div>
            <label className="label" htmlFor="phone">
              Phone
            </label>
            <input id="phone" name="phone" className="input" placeholder="98XXXXXXXX" />
          </div>
        </>
      )}

      <div>
        <label className="label" htmlFor="email">
          Email
        </label>
        <input id="email" name="email" type="email" className="input" required placeholder="you@email.com" />
      </div>
      <div>
        <label className="label" htmlFor="password">
          Password
        </label>
        <input
          id="password"
          name="password"
          type="password"
          className="input"
          required
          minLength={6}
          placeholder="At least 6 characters"
        />
      </div>

      <button className="btn btn-primary w-full" disabled={loading}>
        {loading ? "Please wait…" : mode === "login" ? "Log in" : "Sign up"}
      </button>

      <p className="text-center text-sm text-slate-600">
        {mode === "login" ? (
          <>
            New here?{" "}
            <Link href="/signup" className="font-bold text-brand-700 hover:underline">
              Create an account
            </Link>
          </>
        ) : (
          <>
            Already registered?{" "}
            <Link href="/login" className="font-bold text-brand-700 hover:underline">
              Log in
            </Link>
          </>
        )}
      </p>
    </form>
  );
}
