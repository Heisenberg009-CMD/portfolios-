"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/admin", label: "Dashboard", icon: "📊" },
  { href: "/admin/courses", label: "Courses", icon: "🎓" },
  { href: "/admin/videos", label: "Videos", icon: "🎬" },
  { href: "/admin/notes", label: "Notes", icon: "📝" },
  { href: "/admin/posts", label: "Blog", icon: "✍️" },
  { href: "/admin/pages", label: "Pages", icon: "📄" },
  { href: "/admin/users", label: "Users", icon: "👥" },
  { href: "/admin/payments", label: "Payments", icon: "💳" },
  { href: "/admin/messages", label: "Messages", icon: "📨" },
  { href: "/admin/settings", label: "Settings", icon: "⚙️" },
];

export default function AdminNav({ mobile = false }: { mobile?: boolean }) {
  const pathname = usePathname();

  if (mobile) {
    return (
      <nav className="mb-5 flex gap-2 overflow-x-auto pb-2">
        {LINKS.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className={`whitespace-nowrap rounded-lg px-3 py-2 text-xs font-bold ${
              pathname === l.href ? "bg-brand-600 text-white" : "bg-white text-slate-600 border border-slate-200"
            }`}
          >
            {l.icon} {l.label}
          </Link>
        ))}
      </nav>
    );
  }

  return (
    <nav className="mt-7 grid gap-1">
      {LINKS.map((l) => (
        <Link
          key={l.href}
          href={l.href}
          className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition ${
            pathname === l.href ? "bg-white text-brand-800" : "text-brand-100 hover:bg-white/10"
          }`}
        >
          <span>{l.icon}</span>
          {l.label}
        </Link>
      ))}
    </nav>
  );
}
