import Image from "next/image";
import Link from "next/link";
import { NAV_LINKS, SITE } from "@/lib/site";
import type { SiteSettings } from "@/lib/settings";

export default function SiteFooter({ settings }: { settings: SiteSettings }) {
  return (
    <footer className="mt-16 bg-brand-900 text-brand-100">
      <div className="container-x grid gap-10 py-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <Image
              src={SITE.logo}
              alt={SITE.name}
              width={54}
              height={54}
              className="h-14 w-14 rounded-full bg-white object-cover"
            />
            <div>
              <p className="text-lg font-extrabold text-white">{SITE.name}</p>
              <p className="text-sm text-brand-200">{SITE.tagline}</p>
            </div>
          </div>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-brand-200">
            A student-first learning platform from Jhapa, Nepal — offering affordable courses,
            downloadable notes, recorded video classes and exam guidance so every learner can
            achieve excellence.
          </p>
          <p className="mt-4 text-xs font-semibold uppercase tracking-wide text-brand-300">
            {SITE.motto}
          </p>
        </div>

        <div>
          <p className="mb-3 text-sm font-bold uppercase tracking-wide text-white">Explore</p>
          <ul className="space-y-2 text-sm">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="hover:text-white">
                  {link.label}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/payment" className="hover:text-white">
                Payment / eSewa
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <p className="mb-3 text-sm font-bold uppercase tracking-wide text-white">Contact</p>
          <ul className="space-y-2 text-sm">
            <li>
              📞{" "}
              <a href={`tel:${settings.phone}`} className="hover:text-white">
                {settings.phone}
              </a>
            </li>
            <li>
              ✉️{" "}
              <a href={`mailto:${settings.email}`} className="hover:text-white">
                {settings.email}
              </a>
            </li>
            <li>📍 {settings.address}</li>
          </ul>
          <div className="mt-4 flex gap-3 text-sm">
            <a href={settings.facebook} className="hover:text-white" target="_blank" rel="noreferrer">
              Facebook
            </a>
            <a href={settings.youtube} className="hover:text-white" target="_blank" rel="noreferrer">
              YouTube
            </a>
            <a href={settings.tiktok} className="hover:text-white" target="_blank" rel="noreferrer">
              TikTok
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-brand-300">
        © {new Date().getFullYear()} {SITE.name}. All rights reserved. · Payments via eSewa (
        {settings.esewaName} — {settings.esewaId})
      </div>
    </footer>
  );
}
