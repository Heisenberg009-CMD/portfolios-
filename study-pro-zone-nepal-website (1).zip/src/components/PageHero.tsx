export default function PageHero({
  title,
  subtitle,
  eyebrow,
}: {
  title: string;
  subtitle?: string;
  eyebrow?: string;
}) {
  return (
    <section className="bg-gradient-to-r from-brand-900 to-brand-600 py-12 text-white sm:py-16">
      <div className="container-x">
        {eyebrow && <span className="badge bg-white/15 text-white">{eyebrow}</span>}
        <h1 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">{title}</h1>
        {subtitle && <p className="mt-3 max-w-2xl text-brand-100">{subtitle}</p>}
      </div>
    </section>
  );
}
